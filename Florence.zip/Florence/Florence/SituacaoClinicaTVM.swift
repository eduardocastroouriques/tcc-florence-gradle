//
//  SituacaoClinicaTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol SituacaoClinicaTVMDelegate {
    func didUpdateSituacaoClinica()
    func didFail(with error: String)
}

class SituacaoClinicaTVM {
    
    var situacao : SituacaoClinica?
    var processoID : Int?
    var delegate : SituacaoClinicaTVMDelegate!
    
    func updateSituacao() {
        guard let situacao = situacao , let idProcess = processoID else { return }
        SituacaoClinicaService().updateSituacaoClinica(idProcesso: idProcess, situacaoClinica: situacao, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateSituacaoClinica()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }    }
}

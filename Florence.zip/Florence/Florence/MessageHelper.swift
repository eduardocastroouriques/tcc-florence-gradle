//
//  MessageHelper.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 12/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import UIKit
import Whisper

class MessageHelper {
    
    static func showMessage(message: String, backgroundColor: UIColor) {
        var murmur = Murmur(title: message)
        murmur.backgroundColor = backgroundColor
        murmur.titleColor = UIColor.white
        let duration = backgroundColor == Colors.strongBlue ? 1.0 : 3.5
        Whisper.show(whistle: murmur, action: .show(duration))
    }
}

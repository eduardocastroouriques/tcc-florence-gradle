//
//  ExameClinicoTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class TesteClinicoTVC: BaseTableViewController {
    
    @IBOutlet weak var segmentedNumero : UISegmentedControl!
    @IBOutlet weak var lblData : UILabel!
    @IBOutlet weak var lblHora : UILabel!
    @IBOutlet weak var txtMedico : UITextField!
    
    var isNew = false
    var model = TesteClinicoTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Teste Clínico"
        if isNew == false {
            setupContent()
        }
        model.delegate = self
        setBackButtonTextEmpty()
    }
    
    func setupContent() {
        if let num = model.testeClinico?.numeroTeste {
            segmentedNumero.selectedSegmentIndex = num 
        }
        lblData.text = model.testeClinico?.dataTesteClinico != nil ? model.testeClinico?.dataTesteClinico!.toDateFrontEndFormat() : "Selecionar"
        lblHora.text = model.testeClinico?.horaTesteClinico ?? "Selecionar"
        txtMedico.text = model.testeClinico?.medico ?? "Não Informado"
    }
    
    func loadDataToModel() {
        if isNew {
            model.testeClinico = TesteClinico()
        }
        if let test = model.testeClinico {
            test.dataTesteClinico = lblData.text == "Selecionar" ? nil : lblData.text?.toDateBackEndFormat()
            test.horaTesteClinico = lblHora.text == "Selecionar" ? nil : lblHora.text
            test.medico = txtMedico.text
            test.numeroTeste = segmentedNumero.selectedSegmentIndex
        }
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateTeste()
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora Teste",time: lblHora.text == "Selecionar" ? nil : lblHora.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHora.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonDataTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblData.text == "Selecionar" ? Date() : lblData.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date, didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblData.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
}

extension TesteClinicoTVC : TesteClinicoTVMDelegate {

    func didUpdateTeste() {
        backToMenu()
    }
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}

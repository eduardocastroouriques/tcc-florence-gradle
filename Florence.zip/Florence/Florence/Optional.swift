//
//  Optional.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 11/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

extension Optional {
    func `or`(_ value : Wrapped?) -> Optional {
        return self ?? value
    }
    func `or`(_ value: Wrapped) -> Wrapped {
        return self ?? value
    }
}

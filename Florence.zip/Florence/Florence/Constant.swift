//
//  Constant.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

struct Colors {
    
    static let strongBlue : UIColor = #colorLiteral(red: 0.2705882353, green: 0.3450980392, blue: 0.4745098039, alpha: 1)
    static let lightBlue : UIColor = #colorLiteral(red: 0.5725490196, green: 0.8039215686, blue: 0.8117647059, alpha: 1)
    static let lightPink : UIColor = #colorLiteral(red: 0.9607843137, green: 0.5647058824, blue: 0.5607843137, alpha: 1)
    static let backgroundBlue : UIColor = #colorLiteral(red: 0.9333333333, green: 0.937254902, blue: 0.968627451, alpha: 1)
    static let strongPink : UIColor = #colorLiteral(red: 0.937254902, green: 0.2901960784, blue: 0.2862745098, alpha: 1)
    
}

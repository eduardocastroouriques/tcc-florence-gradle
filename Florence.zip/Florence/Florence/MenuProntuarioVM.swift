//
//  MenuProntuarioVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

class MenuProntuarioVM {
    
    var currentProntuario : ProcessoDoacao?
}

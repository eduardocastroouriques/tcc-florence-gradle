//
//  ExameComplementarVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol ExameComplementarListVMDelegate {
    func didFetchExames()
    func didFail(with error: String)
}

class ExameComplementarListVM {
    
    var exames : [ExameComplementar]?
    var processoID : Int?
    var delegate : ExameComplementarListVMDelegate!
    
    func fetchExames() {
        guard let id = processoID else { return }
        ExameComplementarService().fetchAllExames(idProcesso: id, success: { [weak self] (data) in
            guard let s = self else { return }
            s.exames = data
            s.delegate.didFetchExames()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }

}

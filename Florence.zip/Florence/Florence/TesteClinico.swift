
import Foundation
import ObjectMapper


class TesteClinico : NSObject, NSCoding, Mappable{
    
    var dataTesteClinico : String?
    var horaTesteClinico : String?
    var medico : String?
    var numeroTeste : Int?
    var oid : Int?
    
    class func newInstance(map: Map) -> Mappable?{
        return TesteClinico()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        dataTesteClinico <- map["dataTesteClinico"]
        horaTesteClinico <- map["horaTesteClinico"]
        medico <- map["medico"]
        numeroTeste <- map["numeroTeste"]
        oid <- map["oid"]
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        dataTesteClinico = aDecoder.decodeObject(forKey: "dataTesteClinico") as? String
        horaTesteClinico = aDecoder.decodeObject(forKey: "horaTesteClinico") as? String
        medico = aDecoder.decodeObject(forKey: "medico") as? String
        numeroTeste = aDecoder.decodeObject(forKey: "numeroTeste") as? Int
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
    
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if dataTesteClinico != nil{
            aCoder.encode(dataTesteClinico, forKey: "dataTesteClinico")
        }
        if horaTesteClinico != nil{
            aCoder.encode(horaTesteClinico, forKey: "horaTesteClinico")
        }
        if medico != nil{
            aCoder.encode(medico, forKey: "medico")
        }
        if numeroTeste != nil{
            aCoder.encode(numeroTeste, forKey: "numeroTeste")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
    }
}

//
//  Token.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

struct Token {

    static func retrieve() -> String? {
        guard let token = UserDefaults.standard.value(forKey: "token") as? String else {return nil}
        return token
    }
    
    static func set(token: String) {
        UserDefaults.standard.setValue(token, forKey: "token")
    }
}

//
//  UIView.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 27/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

extension UIView {
    
    func centerIn(_ view: UIView) {
        let x = CGFloat(Int(view.frame.width/2))
        let y = CGFloat(Int(view.frame.height/2))
        let p = CGPoint(x: x, y: y)
        center = p
    }
    
    static func loadFromNib(name: String) -> UIView? {
        return Bundle.main.loadNibNamed(name, owner: nil, options: nil)?.first as? UIView
    }
}

//
//  SituacaoClinicaVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class SituacaoClinicaListVC: BaseViewController {
    
    @IBOutlet weak var tableView : UITableView!
    
    var model = SituacaoClinicaListVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Situações Clínicas"
        setBackButtonTextEmpty()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchSituacoesClinicas()
    }
    
    func setStatusContentLoaded(){
        tableView.reloadData()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        stopLoading()
    }
    func addTapped() {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "SituacaoClinicaTVC") as? SituacaoClinicaTVC else { return }
        vc.model.processoID = model.processoID
        vc.isNew = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage( message: error ,backgroundColor: Colors.strongPink)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToSituacaoClinicaTVC" {
            guard let vc = segue.destination as? SituacaoClinicaTVC, let idx = sender as? IndexPath else { return }
            vc.model.situacao = model.situacoes?[idx.row]
            vc.model.processoID = model.processoID
        }
    }
}


extension SituacaoClinicaListVC : UITableViewDataSource , UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.situacoes?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SituacaoClinicaCell
        cell.content = model.situacoes?[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToSituacaoClinicaTVC", sender: indexPath)
    }
    
}

extension SituacaoClinicaListVC : SituacaoClinicaListVMDelegate {
    func didFetchSituacaoClinica() {
        setStatusContentLoaded()
    }
    
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }

}


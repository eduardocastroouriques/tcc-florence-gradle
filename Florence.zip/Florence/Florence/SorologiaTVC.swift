//
//  SorologiaTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class SorologiaTVC: BaseTableViewController {
    
    @IBOutlet weak var txtLocal : UITextField!
    @IBOutlet weak var segmentedHemodiluicao : UISegmentedControl!
    @IBOutlet weak var lblHoraResultado : UILabel!
    @IBOutlet weak var lblHoraInicio : UILabel!
    @IBOutlet weak var txtAntiHIV : UITextField!
    @IBOutlet weak var txtHBsAg : UITextField!
    @IBOutlet weak var txtHTLVI : UITextField!
    @IBOutlet weak var txtHTLVII : UITextField!
    @IBOutlet weak var txtAntiHBc : UITextField!
    @IBOutlet weak var txtAntiHCV : UITextField!
    @IBOutlet weak var txtAntiHBs : UITextField!
    @IBOutlet weak var txtToxoIgG : UITextField!
    @IBOutlet weak var txtToxoIgM : UITextField!
    @IBOutlet weak var txtChagas : UITextField!
    @IBOutlet weak var txtLues : UITextField!
    @IBOutlet weak var txtCMVIgG : UITextField!
    @IBOutlet weak var txtCMVIgM : UITextField!
    @IBOutlet weak var txtCalculo : UITextField!
    
    var isNew = false
    var model = SorologiaTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Sorologia"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchSorologia()
    }
    
    func setupContent() {
        
        if model.sorologia != nil {
            segmentedHemodiluicao.selectedSegmentIndex = model.sorologia?.hemodiluicao == "0" ? 0 : 1
            txtLocal.text = model.sorologia?.local
            lblHoraInicio.text = model.sorologia?.horaInicio
            lblHoraResultado.text = model.sorologia?.horaResultado
            txtAntiHIV.text = model.sorologia?.antiHIV
            txtHBsAg.text = model.sorologia?.hbsAg
            txtHTLVI.text = model.sorologia?.htlvPrimeiro
            txtHTLVII.text = model.sorologia?.htlvSegundo
            txtAntiHBc.text = model.sorologia?.antiHbc
            txtAntiHCV.text = model.sorologia?.antiHcv
            txtAntiHBs.text = model.sorologia?.antiHbs
            txtToxoIgG.text = model.sorologia?.toxoIgg
            txtToxoIgM.text = model.sorologia?.toxoIgm
            txtChagas.text = model.sorologia?.chagas
            txtLues.text = model.sorologia?.lues
            txtCMVIgM.text = model.sorologia?.cmvim
            txtCMVIgG.text = model.sorologia?.cmvIgc
            if let calc =  model.sorologia?.calculo {
                txtCalculo.text = String(calc)
            }

        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
        if isNew {
            model.sorologia = Sorologia()
        }
        if let sorologia = model.sorologia {
            sorologia.hemodiluicao = String(segmentedHemodiluicao.selectedSegmentIndex)
            sorologia.local = txtLocal.text
            sorologia.horaInicio = lblHoraInicio.text
            sorologia.horaResultado = lblHoraResultado.text
            sorologia.antiHIV = txtAntiHIV.text
            sorologia.hbsAg = txtHBsAg.text
            sorologia.htlvSegundo = txtHTLVII.text
            sorologia.htlvPrimeiro = txtHTLVI.text
            sorologia.antiHbc = txtAntiHBc.text
            sorologia.antiHbs = txtAntiHBs.text
            sorologia.antiHcv = txtAntiHCV.text
            sorologia.toxoIgg = txtToxoIgG.text
            sorologia.toxoIgm = txtToxoIgM.text
            sorologia.chagas = txtChagas.text
            sorologia.lues = txtLues.text
            sorologia.cmvim = txtCMVIgM.text
            sorologia.cmvIgc = txtCMVIgG.text
            if let calc = txtCalculo.text {
                sorologia.calculo = Float(calc)
            }
        }
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateSorologia()
    }
    
    @IBAction func buttonHoraInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora inicio",time: lblHoraInicio.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHoraInicio.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHoraResultadoTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora resultado",time: lblHoraResultado.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHoraResultado.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 11
    }
}

extension SorologiaTVC : SorologiaTVMDelegate {
    func didFailFetchSorologia(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailUpdateSorologia(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didUpdateSorologia() {
        backToMenu()
    }
    
    func didFetchSorologia() {
        setStatusContentLoaded()
    }
}



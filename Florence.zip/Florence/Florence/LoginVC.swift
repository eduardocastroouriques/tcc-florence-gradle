//
//  LoginVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 27/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class LoginVC: BaseViewController {

    
    @IBOutlet weak var contentView : UIView!
    @IBOutlet weak var txtUser: FLTextField!
    @IBOutlet weak var txtPassword: FLTextField!
    @IBOutlet weak var btnLoginTapped: FLButton!
    
    var model = LoginVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = true
        setupTextFields()
        model.delegate = self
    }
    
    func setupTextFields() {
        txtUser.tag = 0
        txtPassword.tag = 1
        txtUser.delegate = self
        txtPassword.delegate = self
    }
    
    @IBAction func loginTapped(_ sender: UIButton) {
//        model.login(user: "suahushuas", password: "ashuasuhashu")
//        btnLoginTapped.isEnabled = false
//        startLoading()
//    }
//        let sb = UIStoryboard(name: "Home", bundle: nil)
//        guard let vc = sb.instantiateInitialViewController() else { return }
//        navigationController?.pushViewController(vc, animated: true)
        performSegue(withIdentifier: "goToUser", sender: nil)
    }
}

extension LoginVC : UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            btnLoginTapped.sendActions(for: .touchUpInside)
            textField.resignFirstResponder()
        }
        return false
    }
}

extension LoginVC : LoginVMDelegate {
    
    func didLogin() {
        guard let token = model.token else {return}
        print("logou com token \(token)")
        stopLoading()
        let sb = UIStoryboard(name: "Home", bundle: nil)
        guard let vc = sb.instantiateInitialViewController() else { return }
        navigationController?.pushViewController(vc, animated: true)
    }

    func didFail(with error: String) {
        print("deu merda")
        btnLoginTapped.isEnabled = true
        stopLoading()
    }
}

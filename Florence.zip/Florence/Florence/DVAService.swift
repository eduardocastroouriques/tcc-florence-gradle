//
//  DVAService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 22/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class DVAService {
    
    func fetchAllDVAs(idProcesso: Int, success: @escaping ([DVA]) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.DVAAll + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestArray(url: url, success: { (data) in
            guard let dvas = data else { return }
            var dvasList : [DVA] = []
            dvas.forEach({
                let t = Mapper<DVA>().map(JSON: $0)
                if t != nil {
                    dvasList.append(t!)
                }
            })
            success(dvasList)
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateDVA(idProcesso: Int , dva: DVA ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.DVA
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: dva.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

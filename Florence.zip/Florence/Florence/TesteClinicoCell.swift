//
//  ExameClinicoCell.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class TesteClinicoCell: UITableViewCell {
    
    @IBOutlet weak var lblNumero: UILabel!
    @IBOutlet weak var lblDataHora: UILabel!
    @IBOutlet weak var lblMedico: UILabel!
    
    var content : TesteClinico? {
        didSet {
            if let num = content?.numeroTeste {
                let numAux = num == 0 ? "Primeiro" : "Segundo"
                lblNumero.text = "Numero: \(numAux)"
            }
            lblMedico.text = "Médico: \(content?.medico ?? "Não informado")"
            lblDataHora.text = "Data/Hora: \(content?.dataTesteClinico.or("01-01-2017").toDateFrontEndFormat() ?? "Não informado") - \(content?.horaTesteClinico ?? "Não informado")"
        }
    }
    
}

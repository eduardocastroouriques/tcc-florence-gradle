//
//  HomeVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 03/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var segmentedStatus: UISegmentedControl!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var model = HomeVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        self.navigationItem.setHidesBackButton(true, animated:true);
        self.title = "Prontuários"
        model.delegate = self
        setBackButtonTextEmpty()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
    }
    
    func addTapped() {
        let sb = UIStoryboard(name: "DadosGerais", bundle: nil)
        guard let vc = sb.instantiateViewController(withIdentifier: "DadosGeraisTVC") as? DadosGeraisTVC else { return }
        vc.isNewProcess = true
        vc.model.processo = ProcessoDoacao()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchRecords()
    }
    
    func setStatusContentLoaded(){
        tableView.reloadData()
        stopLoading()
    }
    
    func setStatusError(error:String) {
        stopLoading()
        print(error)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToMenuProntuario" {
            guard let vc = segue.destination as? MenuProntuarioTVC, let idx = sender as? IndexPath else { return }
                vc.model.currentProntuario = model.processos?[idx.row]
        }
    }
}

extension HomeVC : HomeVMDelegate {
    
    func didDeleteProcesso() {
        model.fetchRecords()
    }
    func didFetchProcessos() {
        setStatusContentLoaded()
    }
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}

extension HomeVC : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.processos?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ProcessoListCell
        cell.content = model.processos?[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "goToMenuProntuario", sender: indexPath)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            guard let process = model.processos?[indexPath.row] else { return }
            guard let id = process.oid else { return }
            startLoading()
            model.deleteRecord(id: id)
        }
    }
    
}

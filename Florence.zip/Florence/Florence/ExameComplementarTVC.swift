//
//  ExameComplementarTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ExameComplementarTVC: BaseTableViewController {
    
    @IBOutlet weak var segmentedExame : UISegmentedControl!
    @IBOutlet weak var txtOutroExame : UITextField!
    @IBOutlet weak var lblData : UILabel!
    @IBOutlet weak var lblHora : UILabel!
    @IBOutlet weak var txtResultado : UITextField!
    @IBOutlet weak var txtMedico : UITextField!
    
    var isNew = false
    var model = ExameComplementarTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Exame Complementar"
        if isNew == false {
            setupContent()
        }
        model.delegate = self
        setBackButtonTextEmpty()
    }
    
    func setupContent() {
        if let tipo = model.exame?.tipo {
            if [0,1,2,3,4].contains(tipo) {
                segmentedExame.selectedSegmentIndex = tipo
            } else {
                segmentedExame.selectedSegmentIndex = 5
                txtOutroExame.text = model.exame?.tipoOutro ?? "Não Informado"
            }
            lblHora.text = model.exame?.horaExame ?? "Não Informado"
            lblData.text = model.exame?.dataExame.or("01-01-2017").toDateFrontEndFormat()
            txtMedico.text = model.exame?.medico ?? "Não Informado"
            txtResultado.text = model.exame?.resultado ?? "Não Informado"
        }
    }
    
    func loadDataToModel() {
        if isNew {
            model.exame = ExameComplementar()
        }
        if let exame = model.exame {
            exame.dataExame = lblData.text?.toDateBackEndFormat()
            exame.horaExame = lblHora.text
            exame.medico = txtMedico.text
            exame.resultado = txtResultado.text
            exame.tipo = segmentedExame.selectedSegmentIndex
            if segmentedExame.selectedSegmentIndex == 4 {
                exame.tipoOutro = txtOutroExame.text
            } else {
                exame.tipoOutro = nil
            }
        }
    }
    
    func backToMenu() {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }

    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateExame()
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora exame",time: lblHora.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHora.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    @IBAction func buttonDataTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let datePicker = CalendarPicker.show(selectedDate: lblData.text?.toDate(), didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblData.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }

}

extension ExameComplementarTVC : ExameComplementarTVMDelegate {
    func didUpdateExame() {
        backToMenu()
    }
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}

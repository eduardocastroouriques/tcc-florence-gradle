//
//  Obito.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class Obito : NSObject, NSCoding, Mappable{
    
    var dataObito : String?
    var horaObito : String?
    var oid : Int?
    var tipo : Int?
    
    class func newInstance(map: Map) -> Mappable?{
        return Obito()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        dataObito <- map["dataObito"]
        horaObito <- map["horaObito"]
        oid <- map["oid"]
        tipo <- map["tipo"]
        
    }

    @objc required init(coder aDecoder: NSCoder)
    {
        dataObito = aDecoder.decodeObject(forKey: "dataObito") as? String
        horaObito = aDecoder.decodeObject(forKey: "horaObito") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        tipo = aDecoder.decodeObject(forKey: "tipo") as? Int
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if dataObito != nil{
            aCoder.encode(dataObito, forKey: "dataObito")
        }
        if horaObito != nil{
            aCoder.encode(horaObito, forKey: "horaObito")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if tipo != nil{
            aCoder.encode(tipo, forKey: "tipo")
        }
        
    }
    
}

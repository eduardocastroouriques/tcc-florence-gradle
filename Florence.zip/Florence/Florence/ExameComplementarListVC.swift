//
//  ExameComplementarListVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ExameComplementarListVC: BaseViewController {

    @IBOutlet weak var tableView : UITableView!
    
    var model = ExameComplementarListVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        title = "Exames Complementares"
        tableView.tableFooterView = UIView()
        setBackButtonTextEmpty()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchExames()
    }
    
    func setStatusContentLoaded(){
        tableView.reloadData()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        stopLoading()
    }
    
    func addTapped() {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ExameComplementarTVC") as? ExameComplementarTVC else { return }
        vc.model.processoID = model.processoID
        vc.isNew = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        guard let navigationController = navigationController else { return }
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToExameComplementarTVC" {
            guard let vc = segue.destination as? ExameComplementarTVC, let idx = sender as? IndexPath else { return }
            vc.model.exame = model.exames?[idx.row]
            vc.model.processoID = model.processoID
        }
    }
}
extension ExameComplementarListVC : UITableViewDataSource , UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.exames?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ExameCell
        cell.content = model.exames?[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToExameComplementarTVC", sender: indexPath)
    }

}

extension ExameComplementarListVC : ExameComplementarListVMDelegate {
    func didFetchExames() {
        setStatusContentLoaded()
    }

    func didFail(with error: String) {
        setStatusError(error: error)
    }
}

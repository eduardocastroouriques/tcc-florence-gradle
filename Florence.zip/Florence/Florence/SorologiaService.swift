//
//  SorologiaService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class SorologiaService {
    
    func fetchSorologia(idProcesso: Int ,success: @escaping (Sorologia) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.sorologiaFetch + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let sorologia = data else {
                success(Sorologia())
                return
            }
            let sor = Mapper<Sorologia>().map(JSON: sorologia)
            if sor != nil {
                success(sor!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateSorologia(idProcesso: Int , sorologia: Sorologia ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.sorologiaUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: sorologia.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

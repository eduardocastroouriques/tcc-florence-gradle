//
//  EntrevistaFamiliarTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class EntrevistaFamiliarTVC: BaseTableViewController {
    
    @IBOutlet weak var segmentedAutorizado : UISegmentedControl!
    @IBOutlet weak var lblData : UILabel!
    @IBOutlet weak var lblHora : UILabel!
    @IBOutlet weak var txtMotivoNegativa : UITextField!
    @IBOutlet weak var txtEntrevistador : UITextField!
    @IBOutlet weak var txtViewObs : UITextView!
    
    var isNew = false
    var model = EntrevistaFamiliarTVM()

    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Entrevista Familiar"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchEntrevista()
    }
    
    func setupContent() {
        if model.entrevista != nil {
            segmentedAutorizado.selectedSegmentIndex = model.entrevista?.resultado ?? 0
            lblData.text = model.entrevista?.dataEntrevista.or("01-01-2017").toDateFrontEndFormat()
            lblHora.text = model.entrevista?.horaEntrevista ?? "Não Informado"
            txtEntrevistador.text = model.entrevista?.entrevistador ?? "Não Informado"
            txtMotivoNegativa.text = model.entrevista?.motivoNegativa ?? "Não Informado"
            txtViewObs.text = model.entrevista?.observacao ?? ""
        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
        if isNew {
            model.entrevista = EntrevistaFamilar()
        }
        if let entrevista = model.entrevista {
            entrevista.dataEntrevista = lblData.text?.toDateBackEndFormat()
            entrevista.horaEntrevista = lblHora.text
            entrevista.resultado = segmentedAutorizado.selectedSegmentIndex
            entrevista.observacao = txtViewObs.text
            entrevista.motivoNegativa = txtMotivoNegativa.text
            entrevista.entrevistador = txtEntrevistador.text
        }
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateEntrevista()
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora entrevista",time: lblHora.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHora.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    @IBAction func buttonDataTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let datePicker = CalendarPicker.show(selectedDate: lblData.text?.toDate(), didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblData.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
}

extension EntrevistaFamiliarTVC : EntrevistaFamiliarTVMDelegate {
    
    func didFailFetchEntrevista(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailUpdateEntrevista(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didUpdateEntrevista() {
        backToMenu()
    }
    
    func didFetchEntrevista() {
        setStatusContentLoaded()
    }
}


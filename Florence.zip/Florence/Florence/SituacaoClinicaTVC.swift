//
//  SituacaoClinicaTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class SituacaoClinicaTVC: BaseTableViewController {
    
    @IBOutlet weak var lblData : UILabel!
    @IBOutlet weak var lblHora : UILabel!
    @IBOutlet weak var txtTA : UITextField!
    @IBOutlet weak var txtDiurese : UITextField!
    @IBOutlet weak var txtSat : UITextField!
    @IBOutlet weak var txtPeep : UITextField!
    @IBOutlet weak var txtPins : UITextField!
    @IBOutlet weak var txtFr : UITextField!
    @IBOutlet weak var txtFio2 : UITextField!
    
    var model = SituacaoClinicaTVM()
    var isNew = false

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Situação Clínica"
        if isNew == false {
            setupContent()
        }
        model.delegate = self
        setBackButtonTextEmpty()
    }
    
    func setupContent() {
        lblData.text = model.situacao?.dataSituacaoClinica.or("01-01-2017").toDateFrontEndFormat()
        lblHora.text = model.situacao?.horaSituacaoClinica
        txtTA.text = model.situacao?.ta
        txtDiurese.text = model.situacao?.diurese
        txtSat.text = model.situacao?.sat
        txtPeep.text = model.situacao?.peep
        txtPins.text = model.situacao?.pins
        txtFr.text = model.situacao?.fr
        txtFio2.text = model.situacao?.fioDois
    }
    
    func loadDataToModel() {
        if isNew {
            model.situacao = SituacaoClinica()
        }
        if let situacao = model.situacao {
            situacao.dataSituacaoClinica = lblData.text?.toDateBackEndFormat()
            situacao.horaSituacaoClinica = lblHora.text
            situacao.ta = txtTA.text
            situacao.diurese = txtDiurese.text
            situacao.sat = txtSat.text
            situacao.peep = txtPeep.text
            situacao.pins = txtPins.text
            situacao.fr = txtFr.text
            situacao.fioDois = txtFio2.text
        }
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage( message: error ,backgroundColor: Colors.strongPink)
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateSituacao()
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora situação clínica",time: lblHora.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHora.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonDataTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let datePicker = CalendarPicker.show(selectedDate: lblData.text?.toDate(), didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblData.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 9
    }
}

extension SituacaoClinicaTVC : SituacaoClinicaTVMDelegate {
    func didUpdateSituacaoClinica() {
        backToMenu()
    }

    func didFail(with error: String) {
        setStatusError(error: error)
    }
}


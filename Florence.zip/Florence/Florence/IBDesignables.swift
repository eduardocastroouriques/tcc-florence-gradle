//
//  IBDesignables.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 27/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
@IBDesignable

public class IBD_View: UIView {
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
            layer.masksToBounds = cornerRadius > 0
        }
    }
    @IBInspectable var borderWidth: CGFloat = 0.5 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    @IBInspectable var borderColor: UIColor? = UIColor.white {
        didSet {
            if borderColor != nil {
                layer.borderColor = borderColor?.cgColor
            }
        }
    }
    
    @IBInspectable var shadowSize: CGFloat = 3
    
    @IBInspectable var hasShadow: Bool = false
    
    @IBInspectable var defaultBorder: Bool = false {
        didSet {
            if defaultBorder {
                layer.borderWidth = 0.5
                layer.borderColor = UIColor.white.cgColor
            }
        }
    }
    
    @IBInspectable var defaultCorner: Bool = false {
        didSet {
            if defaultCorner {
                layer.cornerRadius = 10
            }
        }
    }
    
    @IBInspectable var defaultColor: Bool = false {
        didSet {
            if defaultColor {
                //				backgroundColor = AppUtils.colorMain.withAlpha
            }
        }
    }
    
    @IBInspectable var defaultMiniHeader: Bool = false {
        didSet {
            if defaultMiniHeader {
                //				backgroundColor = AppUtils.colorMiniHeader.background
                layer.borderColor = UIColor.white.cgColor
                layer.borderWidth = 0.5
            }
        }
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        
        if hasShadow {
            addShadow()
        }
    }
    
    func addShadow() {
        IBD_View.applyShadow(self, shadowSize: shadowSize)
    }
    
    class func applyShadow(_ view: UIView, shadowSize: CGFloat = 3) {
        let layer = view.layer
        layer.masksToBounds = false
        layer.shadowOffset = CGSize(width: shadowSize, height: shadowSize)
        layer.shadowOpacity = 0.6
        layer.shadowRadius = 3
    }
    
    class func removeShadow(_ view: UIView) {
        let layer = view.layer
        layer.masksToBounds = true
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0
        layer.shadowRadius = 0
    }
    
    class func applyCornerRadius(_ view: UIView, radius: CGFloat = 10) {
        view.layer.cornerRadius = radius
    }
    
    override public class var layerClass: AnyClass {
        return CAGradientLayer.self
    }
}

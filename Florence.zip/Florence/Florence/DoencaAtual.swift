//
//  DoencaAtual.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class DoencaAtual : NSObject, NSCoding, Mappable{
    
    var aspecto : String?
    var choque : String?
    var craniotomia : String?
    var ddavp : String?
    var dialise : String?
    var diureseUltimasSeisHoras : String?
    var diureseUltimasVinteEQuatroHoras : String?
    var febre : String?
    var ira : String?
    var medicacaoEmUsoDesc : String?
    var observacao : String?
    var oid : Int?
    var pcr : String?
    var pcrNumero : Int?
    var pcrTempoMaximo : String?
    var primeiraCreatinina : String?
    var primeiraCreatininaData : String?
    var secrecaoTot : String?
    var traumaDeAbdome : String?
    var traumaDeTorax : String?
    var vmInicio : String?
    
    
    class func newInstance(map: Map) -> Mappable?{
        return DoencaAtual()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        aspecto <- map["aspecto"]
        choque <- map["choque"]
        craniotomia <- map["craniotomia"]
        ddavp <- map["ddavp"]
        dialise <- map["dialise"]
        diureseUltimasSeisHoras <- map["diureseUltimasSeisHoras"]
        diureseUltimasVinteEQuatroHoras <- map["diureseUltimasVinteEQuatroHoras"]
        febre <- map["febre"]
        ira <- map["ira"]
        medicacaoEmUsoDesc <- map["medicacaoEmUsoDesc"]
        observacao <- map["observacao"]
        oid <- map["oid"]
        pcr <- map["pcr"]
        pcrNumero <- map["pcrNumero"]
        pcrTempoMaximo <- map["pcrTempoMaximo"]
        primeiraCreatinina <- map["primeiraCreatinina"]
        primeiraCreatininaData <- map["primeiraCreatininaData"]
        secrecaoTot <- map["secrecaoTot"]
        traumaDeAbdome <- map["traumaDeAbdome"]
        traumaDeTorax <- map["traumaDeTorax"]
        vmInicio <- map["vmInicio"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        aspecto = aDecoder.decodeObject(forKey: "aspecto") as? String
        choque = aDecoder.decodeObject(forKey: "choque") as? String
        craniotomia = aDecoder.decodeObject(forKey: "craniotomia") as? String
        ddavp = aDecoder.decodeObject(forKey: "ddavp") as? String
        dialise = aDecoder.decodeObject(forKey: "dialise") as? String
        diureseUltimasSeisHoras = aDecoder.decodeObject(forKey: "diureseUltimasSeisHoras") as? String
        diureseUltimasVinteEQuatroHoras = aDecoder.decodeObject(forKey: "diureseUltimasVinteEQuatroHoras") as? String
        febre = aDecoder.decodeObject(forKey: "febre") as? String
        ira = aDecoder.decodeObject(forKey: "ira") as? String
        medicacaoEmUsoDesc = aDecoder.decodeObject(forKey: "medicacaoEmUsoDesc") as? String
        observacao = aDecoder.decodeObject(forKey: "observacao") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        pcr = aDecoder.decodeObject(forKey: "pcr") as? String
        pcrNumero = aDecoder.decodeObject(forKey: "pcrNumero") as? Int
        pcrTempoMaximo = aDecoder.decodeObject(forKey: "pcrTempoMaximo") as? String
        primeiraCreatinina = aDecoder.decodeObject(forKey: "primeiraCreatinina") as? String
        primeiraCreatininaData = aDecoder.decodeObject(forKey: "primeiraCreatininaData") as? String
        secrecaoTot = aDecoder.decodeObject(forKey: "secrecaoTot") as? String
        traumaDeAbdome = aDecoder.decodeObject(forKey: "traumaDeAbdome") as? String
        traumaDeTorax = aDecoder.decodeObject(forKey: "traumaDeTorax") as? String
        vmInicio = aDecoder.decodeObject(forKey: "vmInicio") as? String
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if aspecto != nil{
            aCoder.encode(aspecto, forKey: "aspecto")
        }
        if choque != nil{
            aCoder.encode(choque, forKey: "choque")
        }
        if craniotomia != nil{
            aCoder.encode(craniotomia, forKey: "craniotomia")
        }
        if ddavp != nil{
            aCoder.encode(ddavp, forKey: "ddavp")
        }
        if dialise != nil{
            aCoder.encode(dialise, forKey: "dialise")
        }
        if diureseUltimasSeisHoras != nil{
            aCoder.encode(diureseUltimasSeisHoras, forKey: "diureseUltimasSeisHoras")
        }
        if diureseUltimasVinteEQuatroHoras != nil{
            aCoder.encode(diureseUltimasVinteEQuatroHoras, forKey: "diureseUltimasVinteEQuatroHoras")
        }
        if febre != nil{
            aCoder.encode(febre, forKey: "febre")
        }
        if ira != nil{
            aCoder.encode(ira, forKey: "ira")
        }
        if medicacaoEmUsoDesc != nil{
            aCoder.encode(medicacaoEmUsoDesc, forKey: "medicacaoEmUsoDesc")
        }
        if observacao != nil{
            aCoder.encode(observacao, forKey: "observacao")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if pcr != nil{
            aCoder.encode(pcr, forKey: "pcr")
        }
        if pcrNumero != nil{
            aCoder.encode(pcrNumero, forKey: "pcrNumero")
        }
        if pcrTempoMaximo != nil{
            aCoder.encode(pcrTempoMaximo, forKey: "pcrTempoMaximo")
        }
        if primeiraCreatinina != nil{
            aCoder.encode(primeiraCreatinina, forKey: "primeiraCreatinina")
        }
        if primeiraCreatininaData != nil{
            aCoder.encode(primeiraCreatininaData, forKey: "primeiraCreatininaData")
        }
        if secrecaoTot != nil{
            aCoder.encode(secrecaoTot, forKey: "secrecaoTot")
        }
        if traumaDeAbdome != nil{
            aCoder.encode(traumaDeAbdome, forKey: "traumaDeAbdome")
        }
        if traumaDeTorax != nil{
            aCoder.encode(traumaDeTorax, forKey: "traumaDeTorax")
        }
        if vmInicio != nil{
            aCoder.encode(vmInicio, forKey: "vmInicio")
        }
        
    }
    
}

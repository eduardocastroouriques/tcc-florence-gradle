//
//  ExameDoacaoTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ExameDoacaoTVC: BaseTableViewController {

    @IBOutlet weak var txtRx: UITextField!
    @IBOutlet weak var txtEcg: UITextField!
    @IBOutlet weak var txtEcocardio: UITextField!
    @IBOutlet weak var txtTc: UITextField!
    @IBOutlet weak var txtGasoPulmao: UITextField!
    
    var isNew = false
    var model = ExameDoacaoTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Exame Doação"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchExameDoacao()
    }
    
    func setupContent() {
        if let ex = model.exameDoacao {
            txtRx.text = ex.rx
            txtEcg.text = ex.ecg
            txtEcocardio.text = ex.ecocardio
            txtTc.text = ex.tceCoAbd
            txtGasoPulmao.text = ex.gasoPulmao
        } else {
            isNew = true
        }
        
    }
    
    func loadDataToModel() {
        if isNew {
            model.exameDoacao = ExameDoacao()
        }
        if let ex = model.exameDoacao {
            ex.ecg = txtEcg.text
            ex.rx = txtRx.text
            ex.ecocardio = txtEcocardio.text
            ex.tceCoAbd = txtTc.text
            ex.gasoPulmao = txtGasoPulmao.text
        }
    }
    
    func setStatusContentLoaded() {
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateExameDoacao()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
}

extension ExameDoacaoTVC : ExameDoacaoTVMDelegate {
    
    func didFailUpdateExameDoacao(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailFetchExameDoacao(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didUpdateExameDoacao() {
        backToMenu()
    }
    
    func didFetchExameDoacao() {
        setStatusContentLoaded()
    }
}



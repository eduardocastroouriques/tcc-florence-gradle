//
//  UserService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class UserService {
    
    func login(user:String,password:String, success: @escaping (LoginResponse) -> (), failure: @escaping (String) -> ()) {
        guard let url = URL(string: API.login) else { return }
//        Service.sharedInstance.request(url: url, method: .get, parameters: [:], success: { (JSON) in
//           let res = LoginResponse(token: "test")
//            success(res)
//        }, failure: { (error) in
//            failure(error)
//        })
    }
}

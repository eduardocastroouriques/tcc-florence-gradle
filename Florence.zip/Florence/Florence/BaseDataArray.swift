//
//  BaseData.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class BaseDataArray : NSObject, NSCoding, Mappable{
    
    var data : [[String:Any]]?
    var mensagens : String?
    var status : String?
    var error : String?
    var exception : String?
    
    class func newInstance(map: Map) -> Mappable?{
        return BaseDataArray()
    }
    required init?(map: Map){}
    private override init(){}
    
    func mapping(map: Map)
    {
        data <- map["data"]
        mensagens <- map["mensagens"]
        status <- map["status"]
        exception <- map["exception"]
        error <- map["error"]
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        data = aDecoder.decodeObject(forKey: "data") as? [[String:Any]]
        mensagens = aDecoder.decodeObject(forKey: "mensagens") as? String
        status = aDecoder.decodeObject(forKey: "status") as? String
        exception = aDecoder.decodeObject(forKey: "exception") as? String
        error = aDecoder.decodeObject(forKey: "error") as? String
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if data != nil{
            aCoder.encode(data, forKey: "data")
        }
        if mensagens != nil{
            aCoder.encode(mensagens, forKey: "mensagens")
        }
        if status != nil{
            aCoder.encode(status, forKey: "status")
        }
        if exception != nil{
            aCoder.encode(exception, forKey: "exception")
        }
        if error != nil{
            aCoder.encode(error, forKey: "error")
        }
    }
    
}

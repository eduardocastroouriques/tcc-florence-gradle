//
//  DVAListVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class DVAListVC: BaseViewController {
    
    @IBOutlet weak var tableView : UITableView!
    
    var model = DVAListVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "DVA's"
        setBackButtonTextEmpty()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchDVAs()
    }
    
    func setStatusContentLoaded(){
        tableView.reloadData()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        stopLoading()
    }
    
    func addTapped() {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ToDVATVC") as? DVATVC else { return }
        vc.model.processoID = model.processoID
        vc.isNew = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage( message: error ,backgroundColor: Colors.strongPink)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToDVATVC" {
            guard let vc = segue.destination as? DVATVC, let idx = sender as? IndexPath else { return }
            vc.model.dva = model.dvas?[idx.row]
            vc.model.processoID = model.processoID
        }
    }
}
extension DVAListVC : UITableViewDataSource , UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.dvas?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! DVACell
        cell.content = model.dvas?[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToDVATVC", sender: indexPath)
    }
    
}

extension DVAListVC : DVAListVMDelegate {
    func didFetchDvas() {
        setStatusContentLoaded()
    }
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}


//
//  ExameDoacao.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper

class ExameDoacao : NSObject, NSCoding, Mappable{
    
    var ecg : String?
    var ecocardio : String?
    var gasoPulmao : String?
    var oid : Int?
    var rx : String?
    var tceCoAbd : String?
    
    
    class func newInstance(map: Map) -> Mappable?{
        return ExameDoacao()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        ecg <- map["ecg"]
        ecocardio <- map["ecocardio"]
        gasoPulmao <- map["gasoPulmao"]
        oid <- map["oid"]
        rx <- map["rx"]
        tceCoAbd <- map["tceCoAbd"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        ecg = aDecoder.decodeObject(forKey: "ecg") as? String
        ecocardio = aDecoder.decodeObject(forKey: "ecocardio") as? String
        gasoPulmao = aDecoder.decodeObject(forKey: "gasoPulmao") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        rx = aDecoder.decodeObject(forKey: "rx") as? String
        tceCoAbd = aDecoder.decodeObject(forKey: "tceCoAbd") as? String
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if ecg != nil{
            aCoder.encode(ecg, forKey: "ecg")
        }
        if ecocardio != nil{
            aCoder.encode(ecocardio, forKey: "ecocardio")
        }
        if gasoPulmao != nil{
            aCoder.encode(gasoPulmao, forKey: "gasoPulmao")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if rx != nil{
            aCoder.encode(rx, forKey: "rx")
        }
        if tceCoAbd != nil{
            aCoder.encode(tceCoAbd, forKey: "tceCoAbd")
        }
        
    }
    
}

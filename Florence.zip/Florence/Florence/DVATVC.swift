//
//  DVATVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class DVATVC: BaseTableViewController {
    
    @IBOutlet weak var segmentedNome : UISegmentedControl!
    @IBOutlet weak var lblNome : UILabel!
    @IBOutlet weak var txtAmp : UITextField!
    @IBOutlet weak var txtMLH : UITextField!
    @IBOutlet weak var txtKgMin : UITextField!
    @IBOutlet weak var lblInicio : UILabel!
    @IBOutlet weak var txtKgMinMax : UITextField!
    @IBOutlet weak var txtMLHMax : UITextField!
    
    var isNew = false
    var model = DVATVM()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "DVA"
        if isNew == false {
            setupContent()
        }
        model.delegate = self
        setBackButtonTextEmpty()
    }
    
    func setupContent() {
        if model.dva != nil {
        lblInicio.text = model.dva?.inicio
        segmentedNome.selectedSegmentIndex = getSegmentedNome(nome: model.dva?.nome)
        lblNome.text = getStringForNome(index: segmentedNome.selectedSegmentIndex)
        txtAmp.text = model.dva?.amp
        if let mlPorHora = model.dva?.mlPorHora {
            txtMLH.text = String(mlPorHora)
        }
        if let kg = model.dva?.kg {
            txtKgMin.text = String(kg)
        }
        txtKgMinMax.text = model.dva?.doseMaximaKg
        txtMLHMax.text = model.dva?.doseMaximaMlPorHora
        } else {
            isNew = true
        }
    }
    
    func getSegmentedNome(nome: String?) -> Int {
        guard let nome = nome else { return 0 }
        return model.kvNome.filter({$0.0 == nome}).first?.1 ?? 0
    }
    
    func getStringForNome(index: Int) -> String {
        return model.kvNome.filter({$0.1 == index}).first?.0 ?? ""
    }
    
    func loadDataToModel() {
        
        if isNew {
            model.dva = DVA()
        }
        if let dva = model.dva {
            dva.inicio = lblInicio.text
            dva.nome = getStringForNome(index: segmentedNome.selectedSegmentIndex)
            dva.amp = txtAmp.text
            if let mlPorHora = txtMLH.text {
                dva.mlPorHora = Float(mlPorHora)
            }
            if let kg = txtKgMin.text {
                dva.kg = Float(kg)
            }
            dva.doseMaximaKg = txtKgMinMax.text
            dva.doseMaximaMlPorHora = txtMLHMax.text
        }
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    func setStatusError(error:String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage( message: error ,backgroundColor: Colors.strongPink)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateDVA()
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora inicio",time: lblInicio.text)
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblInicio.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }

    @IBAction func segmentedNomeValueChanged(_ sender: UISegmentedControl) {
        lblNome.text = getStringForNome(index: segmentedNome.selectedSegmentIndex)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
}

extension DVATVC : DVATVMDelegate {

    func didUpdateDVA() {
        backToMenu()
    }

    func didFail(with error: String) {
        setStatusError(error: error)
    }
}


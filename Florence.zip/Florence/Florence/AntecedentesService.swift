//
//  AntecedentesService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper

class AntecedentesService {
    
    func fetchAntecedentes(idProcesso: Int ,success: @escaping (Antecedentes) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.antecedentesFetch + "/\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let antecedentes = data else { return }
            let ant = Mapper<Antecedentes>().map(JSON: antecedentes)
            if ant != nil {
                success(ant!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateAntecedentes(idProcesso: Int , antecedentes: Antecedentes ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.antecedentesUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: antecedentes.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

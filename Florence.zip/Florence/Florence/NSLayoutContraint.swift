//
//  NSLayoutContraint.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import UIKit

extension NSLayoutConstraint {
    
    open class func constraints(_ visualFormat: String, views: [String : Any]) -> [NSLayoutConstraint] {
        
        return NSLayoutConstraint.constraints(withVisualFormat: visualFormat, options: [], metrics: nil, views: views)
    }
    
    @discardableResult open class func activate(_ visualFormat: String, views: [String : Any]) -> [NSLayoutConstraint] {
        let arr = NSLayoutConstraint.constraints(visualFormat, views: views)
        NSLayoutConstraint.activate(arr)
        return arr
    }
}

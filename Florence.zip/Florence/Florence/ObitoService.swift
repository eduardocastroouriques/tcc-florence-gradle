//
//  ObitoSERVICE.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper

class ObitoService {
    
    func fetchObito(idProcesso: Int ,success: @escaping (Obito) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.obitoFetch + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let obt = data else {
                success(Obito())
                return
            }
            let obito = Mapper<Obito>().map(JSON: obt)
            if obito != nil {
                success(obito!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateObito(idProcesso: Int , obito: Obito ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.obitoUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: obito.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}


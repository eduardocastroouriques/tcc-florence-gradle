//
//  BaseTableViewController.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

class BaseTableViewController: UITableViewController {
    
    var popUpContent : UIView?
    var isViewLoadingData : Bool = false {
        didSet {
            blurEffectView.isHidden = self.isViewLoadingData ? false : true
        }
    }
    
    var blurEffectView : UIVisualEffectView!
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        let barHeight = (navigationController?.navigationBar.frame.height).or(44) + UIApplication.shared.statusBarFrame.height
        blurEffectView.frame = CGRect(x: 0, y: barHeight, width: tableView.frame.width, height: tableView.frame.height)
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        activityIndicator.centerIn(blurEffectView)
        
    }
    
    func setBackButtonTextEmpty() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    func startLoading(){
        view.endEditing(true)
        view.isUserInteractionEnabled = false
        if let window = UIApplication.shared.keyWindow {
            window.addSubview(blurEffectView)
            window.addSubview(activityIndicator)
        }
        activityIndicator.startAnimating()
    }
    
    func stopLoading(){
        view.isUserInteractionEnabled = true
        activityIndicator.stopAnimating()
        blurEffectView.removeFromSuperview()
        activityIndicator.stopAnimating()
        activityIndicator.removeFromSuperview()
    }
}

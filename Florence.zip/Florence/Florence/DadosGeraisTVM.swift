//
//  DadosGeraisTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol DadosGeraisTVMDelegate {
    func didFetchProcesso()
    func didUpdateProcesso()
    func didFailToFetch(with error: String)
    func didFailToUpdate(with error: String)
}


class DadosGeraisTVM {
    
    var delegate : DadosGeraisTVMDelegate!
    var processoID : Int?
    var processo : ProcessoDoacao?
    
    var kvEstadoCivil : [(String,Int)] = [("Solteiro",0),("Casado",1), ("Viúvo",2), ("Divorciado",3),("Separado",4)]
    var kvTipoSang : [(String,(Int,Int))] = [("A+",(0,1)),("B+",(1,1)),("AB+",(2,1)),("O+",(3,1)),
                                            ("A-",(0,0)),("B-",(1,0)),("AB+",(2,0)),("O+",(3,0))]
    var kvCausaMorte : [(String,Int)] = [("AVC",0),("TCE",1), ("Anóxia",2), ("Tumor SNC",3),("Outra",4)]
    var kvCircunstancia : [(String,Int)] = [("Homicídio",0),("Suicídio",1), ("Morte N.",2), ("Acidente",3)]
    
    func fetchProcesso(id:Int) {
        ProcessoDoacaoService().fetchRecord(id: id, success: { [weak self] (processo) in
            guard let s = self else { return }
            s.processo = processo
            s.delegate.didFetchProcesso()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailToFetch(with: error)
        }
    }
    
    func updateProcesso() {
        guard let process = processo else { return }
        ProcessoDoacaoService().updateRecord(processo: process, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateProcesso()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailToUpdate(with: error)
        }
    }
}

import Foundation
import ObjectMapper

class EntrevistaFamilar : NSObject, NSCoding, Mappable{
    
    var dataEntrevista : String?
    var entrevistador : String?
    var horaEntrevista : String?
    var motivoNegativa : String?
    var observacao : String?
    var oid : Int?
    var resultado : Int?

    class func newInstance(map: Map) -> Mappable?{
        return EntrevistaFamilar()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        dataEntrevista <- map["dataEntrevista"]
        entrevistador <- map["entrevistador"]
        horaEntrevista <- map["horaEntrevista"]
        motivoNegativa <- map["motivoNegativa"]
        observacao <- map["observacao"]
        oid <- map["oid"]
        resultado <- map["resultado"]
        
    }

    @objc required init(coder aDecoder: NSCoder)
    {
        dataEntrevista = aDecoder.decodeObject(forKey: "dataEntrevista") as? String
        entrevistador = aDecoder.decodeObject(forKey: "entrevistador") as? String
        horaEntrevista = aDecoder.decodeObject(forKey: "horaEntrevista") as? String
        motivoNegativa = aDecoder.decodeObject(forKey: "motivoNegativa") as? String
        observacao = aDecoder.decodeObject(forKey: "observacao") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        resultado = aDecoder.decodeObject(forKey: "resultado") as? Int
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if dataEntrevista != nil{
            aCoder.encode(dataEntrevista, forKey: "dataEntrevista")
        }
        if entrevistador != nil{
            aCoder.encode(entrevistador, forKey: "entrevistador")
        }
        if horaEntrevista != nil{
            aCoder.encode(horaEntrevista, forKey: "horaEntrevista")
        }
        if motivoNegativa != nil{
            aCoder.encode(motivoNegativa, forKey: "motivoNegativa")
        }
        if observacao != nil{
            aCoder.encode(observacao, forKey: "observacao")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if resultado != nil{
            aCoder.encode(resultado, forKey: "resultado")
        }
        
    }
    
}

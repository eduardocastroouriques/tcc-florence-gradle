//
//  AntecedentesTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol AntecedentesTVMDelegate {
    func didUpdateAntecedentes()
    func didFetchAntecedentes()
    func didFail(with error: String)
}

class AntecedentesTVM {
    
    var antecedentes : Antecedentes?
    var processoID : Int?
    var delegate : AntecedentesTVMDelegate!
    
    func fetchAntecedentes() {
        guard let idProcess = processoID else { return }
        AntecedentesService().fetchAntecedentes(idProcesso: idProcess, success: { [weak self] (antecedentes) in
            guard let s = self else { return }
            s.antecedentes = antecedentes
            s.delegate.didFetchAntecedentes()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
    
    func updateAntecedentes() {
        guard let antecedentes = antecedentes , let idProcess = processoID else { return }
        AntecedentesService().updateAntecedentes(idProcesso: idProcess, antecedentes: antecedentes, success: {
            [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateAntecedentes()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
}


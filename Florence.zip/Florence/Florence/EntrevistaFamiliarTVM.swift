//
//  EntrevistaFamiliarTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol EntrevistaFamiliarTVMDelegate {
    func didUpdateEntrevista()
    func didFetchEntrevista()
    func didFailFetchEntrevista(with error: String)
    func didFailUpdateEntrevista(with error: String)
}

class EntrevistaFamiliarTVM {
    
    var entrevista : EntrevistaFamilar?
    var processoID : Int?
    var delegate : EntrevistaFamiliarTVMDelegate!
    
    func fetchEntrevista() {
        guard let idProcess = processoID else { return }
        EntrevistaFamiliarService().fetchEntrevista(idProcesso: idProcess, success: {  [weak self] (entrevista) in
            guard let s = self else { return }
            s.entrevista = entrevista
            s.delegate.didFetchEntrevista()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailFetchEntrevista(with: error)
        }
    }
    
    func updateEntrevista() {
        guard let entrevista = entrevista , let idProcess = processoID else { return }
        EntrevistaFamiliarService().updateEntrevista(idProcesso: idProcess, entrevista: entrevista, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateEntrevista()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailUpdateEntrevista(with: error)
        }
    }
}

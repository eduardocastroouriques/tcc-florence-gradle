//
//  FLButton.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 27/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

class FLButton : UIButton {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    func setup(){
        self.tintColor = UIColor.white
        self.backgroundColor = Colors.strongBlue
        self.layer.cornerRadius = 5
    }
}

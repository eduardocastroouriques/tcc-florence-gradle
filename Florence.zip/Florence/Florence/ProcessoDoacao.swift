import Foundation
import ObjectMapper

class ProcessoDoacao : NSObject, NSCoding, Mappable{
    
    var altura : Float?
    var causaDaMorte : String?
    var causaDaMorteCircunstancia : String?
    var causaDaMorteCircunstanciaAcidente : String?
    var causaDaMorteDecorrenteDe : String?
    var causaDaMorteOutra : String?
    var cns : String?
    var cpf : String?
    var dataInternacao : String?
    var dataNascimento : String?
    var endereco : String?
    var estadoCivil : String?
    var filiacao : String?
    var hospital : String?
    var idade : Int?
    var informante : String?
    var leito : String?
    var nome : String?
    var oid : Int?
    var peso : Float?
    var prontuarioHospital : String?
    var protocoloDataSuspensao : String?
    var protocoloHoraSuspensao : String?
    var protocoloSedacao : String?
    var protocoloTa : String?
    var protocoloTemperatura : Float?
    var rg : String?
    var setor : String?
    var sexo : String?
    var telefone : String?
    var telefoneFamiliar : String?
    var tipagem : String?
    
    class func newInstance(map: Map) -> Mappable?{
        return ProcessoDoacao()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        altura <- map["altura"]
        causaDaMorte <- map["causaDaMorte"]
        causaDaMorteCircunstancia <- map["causaDaMorteCircunstancia"]
        causaDaMorteCircunstanciaAcidente <- map["causaDaMorteCircunstanciaAcidente"]
        causaDaMorteDecorrenteDe <- map["causaDaMorteDecorrenteDe"]
        causaDaMorteOutra <- map["causaDaMorteOutra"]
        cns <- map["cns"]
        cpf <- map["cpf"]
        dataInternacao <- map["dataInternacao"]
        dataNascimento <- map["dataNascimento"]
        endereco <- map["endereco"]
        estadoCivil <- map["estadoCivil"]
        filiacao <- map["filiacao"]
        hospital <- map["hospital"]
        idade <- map["idade"]
        informante <- map["informante"]
        leito <- map["leito"]
        nome <- map["nome"]
        oid <- map["oid"]
        peso <- map["peso"]
        prontuarioHospital <- map["prontuarioHospital"]
        protocoloDataSuspensao <- map["protocoloDataSuspensao"]
        protocoloHoraSuspensao <- map["protocoloHoraSuspensao"]
        protocoloSedacao <- map["protocoloSedacao"]
        protocoloTa <- map["protocoloTa"]
        protocoloTemperatura <- map["protocoloTemperatura"]
        rg <- map["rg"]
        setor <- map["setor"]
        sexo <- map["sexo"]
        telefone <- map["telefone"]
        telefoneFamiliar <- map["telefoneFamiliar"]
        tipagem <- map["tipagem"]
        
    }

    @objc required init(coder aDecoder: NSCoder)
    {
        altura = aDecoder.decodeObject(forKey: "altura") as? Float
        causaDaMorte = aDecoder.decodeObject(forKey: "causaDaMorte") as? String
        causaDaMorteCircunstancia = aDecoder.decodeObject(forKey: "causaDaMorteCircunstancia") as? String
        causaDaMorteCircunstanciaAcidente = aDecoder.decodeObject(forKey: "causaDaMorteCircunstanciaAcidente") as? String
        causaDaMorteDecorrenteDe = aDecoder.decodeObject(forKey: "causaDaMorteDecorrenteDe") as? String
        causaDaMorteOutra = aDecoder.decodeObject(forKey: "causaDaMorteOutra") as? String
        cns = aDecoder.decodeObject(forKey: "cns") as? String
        cpf = aDecoder.decodeObject(forKey: "cpf") as? String
        dataInternacao = aDecoder.decodeObject(forKey: "dataInternacao") as? String
        dataNascimento = aDecoder.decodeObject(forKey: "dataNascimento") as? String
        endereco = aDecoder.decodeObject(forKey: "endereco") as? String
        estadoCivil = aDecoder.decodeObject(forKey: "estadoCivil") as? String
        filiacao = aDecoder.decodeObject(forKey: "filiacao") as? String
        hospital = aDecoder.decodeObject(forKey: "hospital") as? String
        idade = aDecoder.decodeObject(forKey: "idade") as? Int
        informante = aDecoder.decodeObject(forKey: "informante") as? String
        leito = aDecoder.decodeObject(forKey: "leito") as? String
        nome = aDecoder.decodeObject(forKey: "nome") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        peso = aDecoder.decodeObject(forKey: "peso") as? Float
        prontuarioHospital = aDecoder.decodeObject(forKey: "prontuarioHospital") as? String
        protocoloDataSuspensao = aDecoder.decodeObject(forKey: "protocoloDataSuspensao") as? String
        protocoloHoraSuspensao = aDecoder.decodeObject(forKey: "protocoloHoraSuspensao") as? String
        protocoloSedacao = aDecoder.decodeObject(forKey: "protocoloSedacao") as? String
        protocoloTa = aDecoder.decodeObject(forKey: "protocoloTa") as? String
        protocoloTemperatura = aDecoder.decodeObject(forKey: "protocoloTemperatura") as? Float
        rg = aDecoder.decodeObject(forKey: "rg") as? String
        setor = aDecoder.decodeObject(forKey: "setor") as? String
        sexo = aDecoder.decodeObject(forKey: "sexo") as? String
        telefone = aDecoder.decodeObject(forKey: "telefone") as? String
        telefoneFamiliar = aDecoder.decodeObject(forKey: "telefoneFamiliar") as? String
        tipagem = aDecoder.decodeObject(forKey: "tipagem") as? String
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if altura != nil{
            aCoder.encode(altura, forKey: "altura")
        }
        if causaDaMorte != nil{
            aCoder.encode(causaDaMorte, forKey: "causaDaMorte")
        }
        if causaDaMorteCircunstancia != nil{
            aCoder.encode(causaDaMorteCircunstancia, forKey: "causaDaMorteCircunstancia")
        }
        if causaDaMorteCircunstanciaAcidente != nil{
            aCoder.encode(causaDaMorteCircunstanciaAcidente, forKey: "causaDaMorteCircunstanciaAcidente")
        }
        if causaDaMorteDecorrenteDe != nil{
            aCoder.encode(causaDaMorteDecorrenteDe, forKey: "causaDaMorteDecorrenteDe")
        }
        if causaDaMorteOutra != nil{
            aCoder.encode(causaDaMorteOutra, forKey: "causaDaMorteOutra")
        }
        if cns != nil{
            aCoder.encode(cns, forKey: "cns")
        }
        if cpf != nil{
            aCoder.encode(cpf, forKey: "cpf")
        }
        if dataInternacao != nil{
            aCoder.encode(dataInternacao, forKey: "dataInternacao")
        }
        if dataNascimento != nil{
            aCoder.encode(dataNascimento, forKey: "dataNascimento")
        }
        if endereco != nil{
            aCoder.encode(endereco, forKey: "endereco")
        }
        if estadoCivil != nil{
            aCoder.encode(estadoCivil, forKey: "estadoCivil")
        }
        if filiacao != nil{
            aCoder.encode(filiacao, forKey: "filiacao")
        }
        if hospital != nil{
            aCoder.encode(hospital, forKey: "hospital")
        }
        if idade != nil{
            aCoder.encode(idade, forKey: "idade")
        }
        if informante != nil{
            aCoder.encode(informante, forKey: "informante")
        }
        if leito != nil{
            aCoder.encode(leito, forKey: "leito")
        }
        if nome != nil{
            aCoder.encode(nome, forKey: "nome")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if peso != nil{
            aCoder.encode(peso, forKey: "peso")
        }
        if prontuarioHospital != nil{
            aCoder.encode(prontuarioHospital, forKey: "prontuarioHospital")
        }
        if protocoloDataSuspensao != nil{
            aCoder.encode(protocoloDataSuspensao, forKey: "protocoloDataSuspensao")
        }
        if protocoloHoraSuspensao != nil{
            aCoder.encode(protocoloHoraSuspensao, forKey: "protocoloHoraSuspensao")
        }
        if protocoloSedacao != nil{
            aCoder.encode(protocoloSedacao, forKey: "protocoloSedacao")
        }
        if protocoloTa != nil{
            aCoder.encode(protocoloTa, forKey: "protocoloTa")
        }
        if protocoloTemperatura != nil{
            aCoder.encode(protocoloTemperatura, forKey: "protocoloTemperatura")
        }
        if rg != nil{
            aCoder.encode(rg, forKey: "rg")
        }
        if setor != nil{
            aCoder.encode(setor, forKey: "setor")
        }
        if sexo != nil{
            aCoder.encode(sexo, forKey: "sexo")
        }
        if telefone != nil{
            aCoder.encode(telefone, forKey: "telefone")
        }
        if telefoneFamiliar != nil{
            aCoder.encode(telefoneFamiliar, forKey: "telefoneFamiliar")
        }
        if tipagem != nil{
            aCoder.encode(tipagem, forKey: "tipagem")
        }
        
    }
}

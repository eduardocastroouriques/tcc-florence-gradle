//
//  FLTextField.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

class FLTextField : UITextField {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupTextField()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupTextField()
    }
    
    func setupTextField() {
        self.tintColor = Colors.strongBlue
        self.borderStyle = .none
        self.spellCheckingType = .no
        self.autocorrectionType = .no
        
    }

}

//
//  DoencaAtualTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class DoencaAtualTVC: BaseTableViewController {

    @IBOutlet weak var txtViewMedicacoes : UITextView!
    @IBOutlet weak var txtTraumaToxax : UITextField!
    @IBOutlet weak var txtTraumaAbdome : UITextField!
    @IBOutlet weak var segmentedCraniec : UISegmentedControl!
    @IBOutlet weak var segmentedDDAVP : UISegmentedControl!
    @IBOutlet weak var txtChoque : UITextField!
    @IBOutlet weak var txtVMInicio : UITextField!
    @IBOutlet weak var segmentedPCR : UISegmentedControl!
    @IBOutlet weak var txtNumero : UITextField!
    @IBOutlet weak var txtTempoMax : UITextField!
    @IBOutlet weak var txtIRA : UITextField!
    @IBOutlet weak var txtDialise : UITextField!
    @IBOutlet weak var txtDiurese24 : UITextField!
    @IBOutlet weak var txtDiurese6 : UITextField!
    @IBOutlet weak var txtSecrecao : UITextField!
    @IBOutlet weak var txtAspecto : UITextField!
    @IBOutlet weak var txtPrimeiraCreatinina : UITextField!
    @IBOutlet weak var lblDataPrimeiraCreatinina : UILabel!
    @IBOutlet weak var txtFebre : UITextField!
    @IBOutlet weak var txtViewObservacoes : UITextField!
    
    var isNew = false
    var model = DoencaAtualTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Doença Atual"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchDoencaAtual()
    }
    
    func setupContent() {
        if model.doencaAtual != nil {
            
//            segmentedAutorizado.selectedSegmentIndex = model.entrevista?.resultado ?? 0
//            lblData.text = model.entrevista?.dataEntrevista ?? "Não Informado"
//            lblHora.text = model.entrevista?.horaEntrevista ?? "Não Informado"
//            txtEntrevistador.text = model.entrevista?.entrevistador ?? "Não Informado"
//            txtMotivoNegativa.text = model.entrevista?.motivoNegativa ?? "Não Informado"
//            txtViewObs.text = model.entrevista?.observacao ?? ""
        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
//        if isNew {
//            model.entrevista = EntrevistaFamilar()
//        }
//        if let entrevista = model.entrevista {
//            entrevista.dataEntrevista = "2017-01-01"
//            entrevista.horaEntrevista = "10:03:01"
//            entrevista.resultado = segmentedAutorizado.selectedSegmentIndex
//            entrevista.observacao = txtViewObs.text
//            entrevista.motivoNegativa = txtMotivoNegativa.text
//            entrevista.entrevistador = txtEntrevistador.text
//        }
    }
    
    func setStatusError(error:String) {
        print(error)
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        print("Salvou")
        stopLoading()
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateDoencaAtual()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
}

extension DoencaAtualTVC : DoencaAtualTVMDelegate {
    
    func didUpdateDoencaAtual() {
        backToMenu()
    }
    
    func didFetchDoencaAtual() {
        setStatusContentLoaded()
    }
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}



//
//  HomeVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 03/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol HomeVMDelegate {
    func didFetchProcessos()
    func didDeleteProcesso()
    func didFail(with error: String)
}

class HomeVM {
    
    var delegate : HomeVMDelegate!
    var processos : [ProcessoDoacao]? {
        didSet{
            processos = processos?.filter({ $0.nome != "string"})
            processos = processos?.sorted(by: { (p1, p2) -> Bool in
                guard let n1 = p1.nome , let n2 = p2.nome else { return false }
                return n1 < n2
            })
        }
    }
    
    func fetchRecords() {
        ProcessoDoacaoService().fetchAllRecords(success: { [weak self] (data) in
            guard let s = self else { return }
            s.processos = data
            s.delegate.didFetchProcessos()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
    
    func deleteRecord(id: Int) {
        ProcessoDoacaoService().deleteRecord(id: id, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didDeleteProcesso()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }

}

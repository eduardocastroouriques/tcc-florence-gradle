//
//  TesteClinicoService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class TesteClinicoService {

    func fetchAllTests(idProcesso: Int, success: @escaping ([TesteClinico]) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.testeClinicoAll + "/\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestArray(url: url, success: { (data) in
            guard let testes = data else { return }
            var testList : [TesteClinico] = []
            testes.forEach({
                let t = Mapper<TesteClinico>().map(JSON: $0)
                if t != nil {
                    testList.append(t!)
                }
            })
            success(testList)
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateTest(idProcesso: Int , test: TesteClinico ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.testeClinico
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: test.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

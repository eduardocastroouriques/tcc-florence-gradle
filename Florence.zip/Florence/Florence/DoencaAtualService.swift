//
//  DoencaAtualService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class DoencaAtualService {
    
    func fetchDoencaAtual(idProcesso: Int ,success: @escaping (DoencaAtual) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.doencaAtualFetch + "/\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let doencaAtual = data else { return }
            let doenca = Mapper<DoencaAtual>().map(JSON: doencaAtual)
            if doenca != nil {
                success(doenca!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateDoencaAtual(idProcesso: Int , doencaAtual: DoencaAtual ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.doencaAtualUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: doencaAtual.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}


import Foundation
import ObjectMapper

class Sorologia : NSObject, NSCoding, Mappable{
    
    var antiHIV : String?
    var antiHbc : String?
    var antiHbs : String?
    var antiHcv : String?
    var calculo : Float?
    var chagas : String?
    var cmvIgc : String?
    var cmvim : String?
    var hbsAg : String?
    var hemodiluicao : String?
    var horaInicio : String?
    var horaResultado : String?
    var htlvPrimeiro : String?
    var htlvSegundo : String?
    var local : String?
    var lues : String?
    var oid : Int?
    var toxoIgg : String?
    var toxoIgm : String?
    
    class func newInstance(map: Map) -> Mappable?{
        return Sorologia()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        antiHIV <- map["antiHIV"]
        antiHbc <- map["antiHbc"]
        antiHbs <- map["antiHbs"]
        antiHcv <- map["antiHcv"]
        calculo <- map["calculo"]
        chagas <- map["chagas"]
        cmvIgc <- map["cmvIgc"]
        cmvim <- map["cmvim"]
        hbsAg <- map["hbsAg"]
        hemodiluicao <- map["hemodiluicao"]
        horaInicio <- map["horaInicio"]
        horaResultado <- map["horaResultado"]
        htlvPrimeiro <- map["htlvPrimeiro"]
        htlvSegundo <- map["htlvSegundo"]
        local <- map["local"]
        lues <- map["lues"]
        oid <- map["oid"]
        toxoIgg <- map["toxoIgg"]
        toxoIgm <- map["toxoIgm"]
        
    }

    @objc required init(coder aDecoder: NSCoder)
    {
        antiHIV = aDecoder.decodeObject(forKey: "antiHIV") as? String
        antiHbc = aDecoder.decodeObject(forKey: "antiHbc") as? String
        antiHbs = aDecoder.decodeObject(forKey: "antiHbs") as? String
        antiHcv = aDecoder.decodeObject(forKey: "antiHcv") as? String
        calculo = aDecoder.decodeObject(forKey: "calculo") as? Float
        chagas = aDecoder.decodeObject(forKey: "chagas") as? String
        cmvIgc = aDecoder.decodeObject(forKey: "cmvIgc") as? String
        cmvim = aDecoder.decodeObject(forKey: "cmvim") as? String
        hbsAg = aDecoder.decodeObject(forKey: "hbsAg") as? String
        hemodiluicao = aDecoder.decodeObject(forKey: "hemodiluicao") as? String
        horaInicio = aDecoder.decodeObject(forKey: "horaInicio") as? String
        horaResultado = aDecoder.decodeObject(forKey: "horaResultado") as? String
        htlvPrimeiro = aDecoder.decodeObject(forKey: "htlvPrimeiro") as? String
        htlvSegundo = aDecoder.decodeObject(forKey: "htlvSegundo") as? String
        local = aDecoder.decodeObject(forKey: "local") as? String
        lues = aDecoder.decodeObject(forKey: "lues") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        toxoIgg = aDecoder.decodeObject(forKey: "toxoIgg") as? String
        toxoIgm = aDecoder.decodeObject(forKey: "toxoIgm") as? String
        
    }

    @objc func encode(with aCoder: NSCoder)
    {
        if antiHIV != nil{
            aCoder.encode(antiHIV, forKey: "antiHIV")
        }
        if antiHbc != nil{
            aCoder.encode(antiHbc, forKey: "antiHbc")
        }
        if antiHbs != nil{
            aCoder.encode(antiHbs, forKey: "antiHbs")
        }
        if antiHcv != nil{
            aCoder.encode(antiHcv, forKey: "antiHcv")
        }
        if calculo != nil{
            aCoder.encode(calculo, forKey: "calculo")
        }
        if chagas != nil{
            aCoder.encode(chagas, forKey: "chagas")
        }
        if cmvIgc != nil{
            aCoder.encode(cmvIgc, forKey: "cmvIgc")
        }
        if cmvim != nil{
            aCoder.encode(cmvim, forKey: "cmvim")
        }
        if hbsAg != nil{
            aCoder.encode(hbsAg, forKey: "hbsAg")
        }
        if hemodiluicao != nil{
            aCoder.encode(hemodiluicao, forKey: "hemodiluicao")
        }
        if horaInicio != nil{
            aCoder.encode(horaInicio, forKey: "horaInicio")
        }
        if horaResultado != nil{
            aCoder.encode(horaResultado, forKey: "horaResultado")
        }
        if htlvPrimeiro != nil{
            aCoder.encode(htlvPrimeiro, forKey: "htlvPrimeiro")
        }
        if htlvSegundo != nil{
            aCoder.encode(htlvSegundo, forKey: "htlvSegundo")
        }
        if local != nil{
            aCoder.encode(local, forKey: "local")
        }
        if lues != nil{
            aCoder.encode(lues, forKey: "lues")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if toxoIgg != nil{
            aCoder.encode(toxoIgg, forKey: "toxoIgg")
        }
        if toxoIgm != nil{
            aCoder.encode(toxoIgm, forKey: "toxoIgm")
        }
        
    }
    
}

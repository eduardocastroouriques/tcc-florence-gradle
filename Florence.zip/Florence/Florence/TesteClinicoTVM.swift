//
//  TesteClinicoTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol TesteClinicoTVMDelegate {
    func didUpdateTeste()
    func didFail(with error: String)
}

class TesteClinicoTVM {
    
    var testeClinico : TesteClinico?
    var processoID : Int?
    var delegate : TesteClinicoTVMDelegate!
    
    func updateTeste() {
        guard let test = testeClinico , let idProcess = processoID else { return }
        TesteClinicoService().updateTest(idProcesso: idProcess, test: test, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateTeste()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
}

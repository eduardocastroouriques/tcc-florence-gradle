//
//  BaseViewController.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 03/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

class BaseViewController: UIViewController {
    
    var popUpContent : UIView?
    var isViewLoadingData : Bool = false {
        didSet {
            blurEffectView.isHidden = self.isViewLoadingData ? false : true
        }
    }
    
    var blurEffectView : UIVisualEffectView!
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(blurEffectView)
        blurEffectView.isHidden = true
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        activityIndicator.centerIn(blurEffectView)
        view.addSubview(activityIndicator)
        
    }
    
    func setBackButtonTextEmpty() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    func startLoading(){
        view.endEditing(true)
        view.isUserInteractionEnabled = false
        activityIndicator.startAnimating()
        blurEffectView.isHidden = false
    }
    
    func stopLoading(){
        view.isUserInteractionEnabled = true
        activityIndicator.stopAnimating()
        blurEffectView.isHidden = true
    }
}

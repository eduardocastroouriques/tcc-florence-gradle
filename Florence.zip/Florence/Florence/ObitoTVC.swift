//
//  ObitoTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ObitoTVC: BaseTableViewController {

    @IBOutlet weak var lblData : UILabel!
    @IBOutlet weak var lblHora : UILabel!
    @IBOutlet weak var segmentedTipo : UISegmentedControl!
    
    var isNew = false
    var model = ObitoTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Obito"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchObito()
    }
    
    func setupContent() {
        if let obito = model.obito {
            lblData.text = obito.dataObito != nil ? obito.dataObito!.toDateFrontEndFormat() : "Selecionar"
            lblHora.text = obito.horaObito ?? "Selecionar"
            segmentedTipo.selectedSegmentIndex = obito.tipo.or(0)
        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
        if isNew {
            model.obito = Obito()
        }
        if let obito = model.obito {
            obito.dataObito = lblData.text == "Selecionar" ? nil : lblData.text?.toDateBackEndFormat()
            obito.horaObito = lblHora.text == "Selecionar" ? nil : lblHora.text
            obito.tipo = segmentedTipo.selectedSegmentIndex
        }
    }

    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateObito()
    }
    
    @IBAction func buttonDataTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblData.text == "Selecionar" ? Date() : lblData.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblData.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHoraTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora" ,time: lblHora.text == "Selecionar" ? nil : lblHora.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHora.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
}

extension ObitoTVC : ObitoTVMDelegate {
    
    func didFailUpdateObito(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailFetchObito(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didUpdateObito() {
        backToMenu()
    }
    
    func didFetchObito() {
        setStatusContentLoaded()
    }

}




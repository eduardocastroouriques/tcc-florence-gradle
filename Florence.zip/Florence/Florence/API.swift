//
//  API.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

struct API {
    
    static let base = "http://florence-gradle.herokuapp.com/"
    
    // paths
    
    static let login = API.base + "/login"
    static let processoDoacaoAll = API.base + "processo-doacao"
    static let processoDoacao = API.base + "processo-doacao"
    static let testeClinicoAll = API.base + "teste-clinico/processo-doacao/"
    static let testeClinico = API.base + "teste-clinico"
    static let exameComplementarAll = API.base + "exame-complementar/processo-doacao/"
    static let exameComplementar = API.base + "exame-complementar"
    static let entrevistaFamiliarFetch = API.base + "entrevista-familiar/processo-doacao/"
    static let entrevistaFamiliarUpdate = API.base + "entrevista-familiar"
    static let antecedentesFetch = API.base + "doenca-previa/processo-doacao/"
    static let antecedentesUpdate = API.base + "doenca-previa"
    static let DVAAll = API.base + "dva/processo-doacao/"
    static let DVA = API.base + "dva"
    static let sorologiaFetch = API.base + "sorologia/processo-doacao/"
    static let sorologiaUpdate = API.base + "sorologia"
    static let doencaAtualFetch = API.base + "doenca-atual/processo-doacao/"
    static let doencaAtualUpdate = API.base + "doenca-atual"
    static let exameDoacaoFetch = API.base + "exame-doacao/processo-doacao/"
    static let exameDoacaoUpdate = API.base + "exame-doacao"
    static let situacaoClinicaAll = API.base + "situacao-clinica/processo-doacao/"
    static let situacaoClinica = API.base + "situacao-clinica"
    static let obitoFetch = API.base + "obito/processo-doacao/"
    static let obitoUpdate = API.base + "obito"
    static let hlaFetch = API.base + "hla/processo-doacao/"
    static let hlaUpdate = API.base + "hla"

}

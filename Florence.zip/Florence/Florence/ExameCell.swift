//
//  ExameCell.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ExameCell: UITableViewCell {
    
    @IBOutlet weak var lblTipo: UILabel!
    @IBOutlet weak var lblData: UILabel!
    @IBOutlet weak var lblHora: UILabel!
    @IBOutlet weak var lblResultado: UILabel!
    @IBOutlet weak var lblMedico: UILabel!
    
    var content : ExameComplementar? {
        didSet {
            if let tipo = content?.tipo {
                if [0,1,2,3].contains(tipo) {
                    lblTipo.text = tipoToStringValue(tipo: tipo)
                } else {
                    lblTipo.text = content?.tipoOutro ?? "Não Informado"
                }
            } else { lblTipo.text = "Não Informado" }
            lblData.text = content?.dataExame.or("01-01-2017").toDateFrontEndFormat()
            lblMedico.text = content?.medico ?? "Não Informado"
            lblHora.text = content?.horaExame ?? "Não Informado"
            lblResultado.text = content?.resultado ?? "Não Informado"
        }
    }
    
    func tipoToStringValue(tipo: Int) -> String {
        switch tipo {
        case 0:
            return "Doppler"
        case 1:
            return "Arterio"
        case 2:
            return "Cintilo"
        case 3:
            return "Angio"
        default:
            return ""
        }
    }
}

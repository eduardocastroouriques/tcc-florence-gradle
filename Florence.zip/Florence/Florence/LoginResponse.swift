//
//  LoginResponse.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 28/08/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import Alamofire

class LoginResponse : Mappable {
    
    var token : String?
    
    required init?(map: Map){}
    
    func mapping(map: Map) {
        token <- map["token"]
    }

    init(token: String) {
        self.token = token
    }
}

//
//  ExameComplementarTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol ExameComplementarTVMDelegate {
    func didUpdateExame()
    func didFail(with error: String)
}

class ExameComplementarTVM {
    
    var exame : ExameComplementar?
    var processoID : Int?
    var delegate : ExameComplementarTVMDelegate!
    
    func updateExame() {
        guard let exame = exame , let idProcess = processoID else { return }
        ExameComplementarService().updateExame(idProcesso: idProcess, exame: exame, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateExame()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
}


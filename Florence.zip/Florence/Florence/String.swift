//
//  String.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 06/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

extension String {
    
    func toDate() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "pt_BR")
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.date(from: self) ?? Date()
    }
    
    func toDateBackEndFormat() -> String {
        var dateValues = self.components(separatedBy: "/")
        let v = "\(dateValues[2])-\(dateValues[1])-\(dateValues[0])"
        return v
    }
    
    func toDateFrontEndFormat() -> String {
        var dateValues = self.components(separatedBy: "-")
        let v = "\(dateValues[2])/\(dateValues[1])/\(dateValues[0])"
        return v
    }
    
    
}

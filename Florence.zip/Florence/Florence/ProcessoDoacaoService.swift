//
//  ProcessoDoacaoService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 03/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class ProcessoDoacaoService {

    func fetchAllRecords(success: @escaping ([ProcessoDoacao]) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.processoDoacaoAll
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestArray(url: url, success: { (data) in
            guard let processos = data else { return }
            var processosList : [ProcessoDoacao] = []
            processos.forEach({
                let p = Mapper<ProcessoDoacao>().map(JSON: $0)
                if p != nil {
                    processosList.append(p!)
                }
            })
            success(processosList)
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func fetchRecord(id: Int ,success: @escaping (ProcessoDoacao) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.processoDoacao + "/\(id)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let processo = data else { return }
            let p = Mapper<ProcessoDoacao>().map(JSON: processo)
            if p != nil {
            success(p!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateRecord(processo: ProcessoDoacao ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.processoDoacao
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOne(url: url,parameters: processo.toJSON(), success: { (data) in
            success()
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func deleteRecord(id: Int, success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.processoDoacao + "/\(id)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestDelete(url: url, success: {
            success()
        }, failure: { (error) in
            failure(error)
            })
        }
}

//
//  SituacaoClinica.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper

class SituacaoClinica : NSObject, NSCoding, Mappable {
    
    var dataSituacaoClinica : String?
    var diurese : String?
    var fioDois : String?
    var fr : String?
    var horaSituacaoClinica : String?
    var oid : Int?
    var peep : String?
    var pins : String?
    var processoDoacao : ProcessoDoacao?
    var sat : String?
    var ta : String?
    
    class func newInstance(map: Map) -> Mappable?{
        return SituacaoClinica()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        dataSituacaoClinica <- map["dataSituacaoClinica"]
        diurese <- map["diurese"]
        fioDois <- map["fioDois"]
        fr <- map["fr"]
        horaSituacaoClinica <- map["horaSituacaoClinica"]
        oid <- map["oid"]
        peep <- map["peep"]
        pins <- map["pins"]
        sat <- map["sat"]
        ta <- map["ta"]
        
    }

    @objc required init(coder aDecoder: NSCoder)
    {
        dataSituacaoClinica = aDecoder.decodeObject(forKey: "dataSituacaoClinica") as? String
        diurese = aDecoder.decodeObject(forKey: "diurese") as? String
        fioDois = aDecoder.decodeObject(forKey: "fioDois") as? String
        fr = aDecoder.decodeObject(forKey: "fr") as? String
        horaSituacaoClinica = aDecoder.decodeObject(forKey: "horaSituacaoClinica") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        peep = aDecoder.decodeObject(forKey: "peep") as? String
        pins = aDecoder.decodeObject(forKey: "pins") as? String
        sat = aDecoder.decodeObject(forKey: "sat") as? String
        ta = aDecoder.decodeObject(forKey: "ta") as? String
        
    }

    @objc func encode(with aCoder: NSCoder)
    {
        if dataSituacaoClinica != nil{
            aCoder.encode(dataSituacaoClinica, forKey: "dataSituacaoClinica")
        }
        if diurese != nil{
            aCoder.encode(diurese, forKey: "diurese")
        }
        if fioDois != nil{
            aCoder.encode(fioDois, forKey: "fioDois")
        }
        if fr != nil{
            aCoder.encode(fr, forKey: "fr")
        }
        if horaSituacaoClinica != nil{
            aCoder.encode(horaSituacaoClinica, forKey: "horaSituacaoClinica")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if peep != nil{
            aCoder.encode(peep, forKey: "peep")
        }
        if pins != nil{
            aCoder.encode(pins, forKey: "pins")
        }
        if sat != nil{
            aCoder.encode(sat, forKey: "sat")
        }
        if ta != nil{
            aCoder.encode(ta, forKey: "ta")
        }
        
    }
    
}

//
//  ExameDoacaoTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol ExameDoacaoTVMDelegate {
    func didUpdateExameDoacao()
    func didFetchExameDoacao()
    func didFailUpdateExameDoacao(with error: String)
    func didFailFetchExameDoacao(with error: String)
}

class ExameDoacaoTVM {
    
    var exameDoacao : ExameDoacao?
    var processoID : Int?
    var delegate : ExameDoacaoTVMDelegate!
    
    func fetchExameDoacao() {
        guard let idProcess = processoID else { return }
        ExameDoacaoService().fetchExameDoacao(idProcesso: idProcess, success: {  [weak self] (exame) in
            guard let s = self else { return }
            s.exameDoacao = exame
            s.delegate.didFetchExameDoacao()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailFetchExameDoacao(with: error)
        }
    }
    
    func updateExameDoacao() {
        guard let exame = exameDoacao , let idProcess = processoID else { return }
        ExameDoacaoService().updateExameDoacao(idProcesso: idProcess, exame: exame, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateExameDoacao()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailUpdateExameDoacao(with: error)
        }
    }
}

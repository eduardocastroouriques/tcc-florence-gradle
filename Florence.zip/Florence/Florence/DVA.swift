
import Foundation
import ObjectMapper

class DVA : NSObject, NSCoding, Mappable{
    
    var amp : String?
    var doseMaximaKg : String?
    var doseMaximaMlPorHora : String?
    var inicio : String?
    var kg : Float?
    var mlPorHora : Float?
    var nome : String?
    var oid : Int?
    
    class func newInstance(map: Map) -> Mappable?{
        return DVA()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        amp <- map["amp"]
        doseMaximaKg <- map["doseMaximaKg"]
        doseMaximaMlPorHora <- map["doseMaximaMlPorHora"]
        inicio <- map["inicio"]
        kg <- map["kg"]
        mlPorHora <- map["mlPorHora"]
        nome <- map["nome"]
        oid <- map["oid"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        amp = aDecoder.decodeObject(forKey: "amp") as? String
        doseMaximaKg = aDecoder.decodeObject(forKey: "doseMaximaKg") as? String
        doseMaximaMlPorHora = aDecoder.decodeObject(forKey: "doseMaximaMlPorHora") as? String
        inicio = aDecoder.decodeObject(forKey: "inicio") as? String
        kg = aDecoder.decodeObject(forKey: "kg") as? Float
        mlPorHora = aDecoder.decodeObject(forKey: "mlPorHora") as? Float
        nome = aDecoder.decodeObject(forKey: "nome") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        
    }

    @objc func encode(with aCoder: NSCoder)
    {
        if amp != nil{
            aCoder.encode(amp, forKey: "amp")
        }
        if doseMaximaKg != nil{
            aCoder.encode(doseMaximaKg, forKey: "doseMaximaKg")
        }
        if doseMaximaMlPorHora != nil{
            aCoder.encode(doseMaximaMlPorHora, forKey: "doseMaximaMlPorHora")
        }
        if inicio != nil{
            aCoder.encode(inicio, forKey: "inicio")
        }
        if kg != nil{
            aCoder.encode(kg, forKey: "kg")
        }
        if mlPorHora != nil{
            aCoder.encode(mlPorHora, forKey: "mlPorHora")
        }
        if nome != nil{
            aCoder.encode(nome, forKey: "nome")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        
    }
    
}

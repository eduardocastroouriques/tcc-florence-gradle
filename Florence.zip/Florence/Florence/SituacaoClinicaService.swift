//
//  SituacaoClinicaService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class SituacaoClinicaService {
    
    func fetchAllSituacaoClinica(idProcesso: Int, success: @escaping ([SituacaoClinica]) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.situacaoClinicaAll + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestArray(url: url, success: { (data) in
            guard let situacoes = data else { return }
            var situacaoList : [SituacaoClinica] = []
            situacoes.forEach({
                let s = Mapper<SituacaoClinica>().map(JSON: $0)
                if s != nil {
                    situacaoList.append(s!)
                }
            })
            success(situacaoList)
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateSituacaoClinica(idProcesso: Int , situacaoClinica: SituacaoClinica ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.situacaoClinica
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: situacaoClinica.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

//
//  DVATVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 22/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol DVATVMDelegate {
    func didUpdateDVA()
    func didFail(with error: String)
}

class DVATVM {
    
    var dva : DVA?
    var processoID : Int?
    var delegate : DVATVMDelegate!
    var kvNome : [(String,Int)] = [("Noradrenalina",0),("Vasopressina",1), ("Adrenalina",2), ("Dopamina",3),("Dobutamina",4)]
    
    func updateDVA() {
        guard let dva = dva , let idProcess = processoID else { return }
        DVAService().updateDVA(idProcesso: idProcess, dva: dva, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateDVA()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
}

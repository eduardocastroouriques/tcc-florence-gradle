//
//  AntecedentesTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class AntecedentesTVC: BaseTableViewController {
    
    @IBOutlet weak var txtHas: UITextField!
    @IBOutlet weak var lblHasDate: UILabel!
    @IBOutlet weak var txtDm: UITextField!
    @IBOutlet weak var lblDmDate: UILabel!
    @IBOutlet weak var txtIrc: UITextField!
    @IBOutlet weak var txtDpoc: UITextField!
    @IBOutlet weak var txtHepatiteHiv: UITextField!
    @IBOutlet weak var txtAsma: UITextField!
    @IBOutlet weak var txtIam: UITextField!
    @IBOutlet weak var txtDoencaSnc: UITextField!
    @IBOutlet weak var txtDoencaOcular: UITextField!
    @IBOutlet weak var txtTuberculose: UITextField!
    @IBOutlet weak var txtTto: UITextField!
    @IBOutlet weak var txtViewCirurgiaPrevia: UITextView!
    @IBOutlet weak var txtViewOutraDoencas: UITextView!
    @IBOutlet weak var txtTransfusao: UITextField!
    @IBOutlet weak var lblTransfusaoDate: UILabel!
    @IBOutlet weak var txtViewVacinasRecentes: UITextView!
    @IBOutlet weak var segmentedEtilismo: UISegmentedControl!
    @IBOutlet weak var txtEtilismoTipo: UITextField!
    @IBOutlet weak var txtEtilismoTempo: UITextField!
    @IBOutlet weak var segmentedTabagismo: UISegmentedControl!
    @IBOutlet weak var txtTabagismoTipo: UITextField!
    @IBOutlet weak var txtTabagismoTempo: UITextField!
    @IBOutlet weak var segmentedDrogas: UISegmentedControl!
    @IBOutlet weak var txtDrogasTipo: UITextField!
    @IBOutlet weak var txtDrogasTempo: UITextField!
    @IBOutlet weak var segmentedPrisao: UISegmentedControl!
    @IBOutlet weak var txtPrisaoQuando: UITextField!
    @IBOutlet weak var segmentedHomosexual: UISegmentedControl!
    @IBOutlet weak var segmentedPiercing: UISegmentedControl!
    @IBOutlet weak var segmentedTatuagem: UISegmentedControl!
    @IBOutlet weak var segmentedMaquiagem: UISegmentedControl!
    @IBOutlet weak var txtNomeInformante: UITextField!
    @IBOutlet weak var txtParentescoInformante: UITextField!
    
    var isNew = false
    var model = AntecedentesTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "Antecedentes"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchAntecedentes()
    }
    
    func setupContent() {
        if let ant = model.antecedentes {
            txtHas.text = ant.has
            lblHasDate.text = ant.hasDesde
            txtDm.text = ant.dm
            lblDmDate.text = ant.dmdesde
            txtIrc.text = ant.irc
            txtDpoc.text = ant.dpoc
            txtHepatiteHiv.text = ant.hepatite
            txtAsma.text = ant.asma
            txtIam.text = ant.iam
            txtDoencaSnc.text = ant.doencaSnc
            txtDoencaOcular.text = ant.doencaOcular
            txtTuberculose.text = ant.tuberculose
            txtTto.text = ant.tuberculoseTTO
            txtViewCirurgiaPrevia.text = ant.cirurgiaPrevia
            txtViewOutraDoencas.text = ant.outrasDoencas
            txtTransfusao.text = ant.transfusao
            lblTransfusaoDate.text = ant.dataTransfusao
            txtViewVacinasRecentes.text = ant.vacinasRecentes
            //faltando etilismo
            //tipo - quanto
            
        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
//        if isNew {
//            model.entrevista = EntrevistaFamilar()
//        }
//        if let entrevista = model.entrevista {
//            entrevista.dataEntrevista = "2017-01-01"
//            entrevista.horaEntrevista = "10:03:01"
//            entrevista.resultado = segmentedAutorizado.selectedSegmentIndex
//            entrevista.observacao = txtViewObs.text
//            entrevista.motivoNegativa = txtMotivoNegativa.text
//            entrevista.entrevistador = txtEntrevistador.text
//        }
    }
    
    func setStatusError(error:String) {
        print(error)
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        print("Salvou")
        stopLoading()
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateAntecedentes()
    }
    
    @IBAction func btnNeoplasiaTapped(_ sender : UIButton) {
        performSegue(withIdentifier: "goToNeoplasiaTVC", sender: nil)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 25
    }
}

extension AntecedentesTVC : AntecedentesTVMDelegate {
    func didUpdateAntecedentes() {
        backToMenu()
    }
    
    func didFetchAntecedentes() {
        setStatusContentLoaded()
    }
    
    func didFail(with error: String) {
        setStatusError(error: error)
    }
}



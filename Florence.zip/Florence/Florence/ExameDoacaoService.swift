//
//  ExameDoacaoService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class ExameDoacaoService {
    
    func fetchExameDoacao(idProcesso: Int ,success: @escaping (ExameDoacao) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.exameDoacaoFetch + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let exameDoacao = data else {
                success(ExameDoacao())
                return
            }
            let exame = Mapper<ExameDoacao>().map(JSON: exameDoacao)
            if exame != nil {
                success(exame!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateExameDoacao(idProcesso: Int , exame: ExameDoacao ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.exameDoacaoUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: exame.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}


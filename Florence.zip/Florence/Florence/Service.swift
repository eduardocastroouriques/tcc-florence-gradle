//
//  Service.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 02/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import Alamofire
import ObjectMapper

class Service {

    static let sharedInstance = Service()
    private init(){}
    
    func requestGetOne(url: URL, success: @escaping (([String:Any]?) -> Void), failure: @escaping ((String) -> Void), headers: [String:Any]? = nil) {
        Alamofire.request(url).responseObject { (response: DataResponse<BaseData>) in
            let response = response.result.value
            if response?.status == "OK" {
                success(response?.data)
            } else {
                failure(response?.mensagens ?? "Erro Desconhecido.")
            }
        }
    }
    
    func requestDelete(url: URL, success: @escaping (() -> Void), failure: @escaping ((String) -> Void), headers: [String:Any]? = nil) {
        Alamofire.request(url, method: .delete, parameters: nil, encoding: JSONEncoding.default).responseObject { (response: DataResponse<BaseData>) in
            let response = response.result.value
            if response?.status == "DELETED" {
                success()
            } else {
                failure(response?.mensagens ?? "Erro Desconhecido.")
            }
        }
    }
    
    func requestPostOne(url: URL, parameters: [String:Any], success: @escaping (() -> Void), failure: @escaping ((String) -> Void)) {
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).responseObject { (response: DataResponse<BaseData>) in
        let response = response.result.value
        if response?.status == "CREATED" {
            success()
        } else {
            failure(response?.mensagens ?? "Erro Desconhecido.")
        }
        }
    }
    
    func requestPostOneNested(url: URL, parameters: [String:Any], processId: Int , success: @escaping (() -> Void), failure: @escaping ((String) -> Void)) {
        var newParams = parameters
        newParams["processoDoacao"] = ["oid":processId]
        let method : HTTPMethod  = parameters["oid"] == nil ? .post : .put
        Alamofire.request(url, method: method, parameters: newParams, encoding: JSONEncoding.default).responseObject { (response: DataResponse<BaseData>) in
            let response = response.result.value
            if response?.status == "CREATED" || response?.status == "OK" {
                success()
            } else {
                failure(response?.mensagens ?? "Erro Desconhecido.")
            }
        }
    }
    
    func requestArray(url: URL, success: @escaping (([[String:Any]]?) -> Void), failure: @escaping ((String) -> Void)) {
        Alamofire.request(url).responseObject { (response: DataResponse<BaseDataArray>) in
            let response = response.result.value
            if response?.status == "OK" {
                success(response?.data)
            } else {
                failure(response?.mensagens ?? "Erro Desconhecido.")
            }
        }
    }
}

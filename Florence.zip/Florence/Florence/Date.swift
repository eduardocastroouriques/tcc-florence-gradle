//
//  DateHelper.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

extension Date {
    
    func toStringFrontEnd() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "pt_BR")
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: self)
    }
}


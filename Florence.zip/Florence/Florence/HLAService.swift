//
//  HLAService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class HLAService {
    
    func fetchHLA(idProcesso: Int ,success: @escaping (HLA) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.hlaFetch + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let hlaData = data else {
                success(HLA())
                return
            }
            let hla = Mapper<HLA>().map(JSON: hlaData)
            if hla != nil {
                success(hla!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateHLA(idProcesso: Int , hla: HLA ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.hlaUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: hla.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}


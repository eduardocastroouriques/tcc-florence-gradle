//
//  SituacaoClinicaListVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol SituacaoClinicaListVMDelegate {
    func didFetchSituacaoClinica()
    func didFail(with error: String)
}

class SituacaoClinicaListVM {
    
    var situacoes : [SituacaoClinica]?
    var processoID : Int?
    var delegate : SituacaoClinicaListVMDelegate!
    
    func fetchSituacoesClinicas() {
        guard let id = processoID else { return }
        SituacaoClinicaService().fetchAllSituacaoClinica(idProcesso: id, success: { [weak self] (data) in
            guard let s = self else { return }
            s.situacoes = data
            s.delegate.didFetchSituacaoClinica()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
    
}

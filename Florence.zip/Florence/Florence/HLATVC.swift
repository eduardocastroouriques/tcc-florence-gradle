//
//  HLATVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class HLATVC: BaseTableViewController {

    @IBOutlet weak var lblDataInicio: UILabel!
    @IBOutlet weak var lblHoraInicio: UILabel!
    @IBOutlet weak var lblHoraTermino: UILabel!
    @IBOutlet weak var txtLaboratorio: UITextField!
    @IBOutlet weak var lblHCPAHoraInicio: UILabel!
    @IBOutlet weak var lblHCPADataInicio: UILabel!
    @IBOutlet weak var lblHCPAHoraFim: UILabel!
    @IBOutlet weak var lblHCPADataFim: UILabel!
    @IBOutlet weak var lblISCMPAHoraInicio: UILabel!
    @IBOutlet weak var lblISCMPADataInicio: UILabel!
    @IBOutlet weak var lblISCMPAHoraFim: UILabel!
    @IBOutlet weak var lblISCMPADataFim: UILabel!
    
    var isNew = false
    var model = HLATVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        model.delegate = self
        self.title = "HLA"
        setBackButtonTextEmpty()
        setStatusContentLoading()
    }
    
    func setStatusContentLoading() {
        startLoading()
        model.fetchHLA()
    }
    
    func setupContent() {
        if let hla = model.hla {
            lblDataInicio.text = hla.dataInicio != nil ? hla.dataInicio!.toDateFrontEndFormat() : "Selecionar"
            lblHoraInicio.text = hla.horaInicio ?? "Selecionar"
            lblHoraTermino.text = hla.horaTermino ?? "Selecionar"
            txtLaboratorio.text = hla.laboratorio
            lblHCPADataInicio.text = hla.crossHcpaDataInicio != nil ? hla.crossHcpaDataInicio!.toDateFrontEndFormat() : "Selecionar"
            lblHCPADataFim.text = hla.crossHcpaDataFim != nil ? hla.crossHcpaDataFim!.toDateFrontEndFormat() : "Selecionar"
            lblHCPAHoraInicio.text = hla.crossHcpaHoraInicio ?? "Selecionar"
            lblHCPAHoraFim.text = hla.crossHcpaHoraFim ?? "Selecionar"
            lblISCMPADataInicio.text = hla.crossIscmpaDataInicio != nil ? hla.crossIscmpaDataInicio!.toDateFrontEndFormat() : "Selecionar"
            lblISCMPADataFim.text = hla.crossIscmpaDataFim != nil ? hla.crossIscmpaDataFim!.toDateFrontEndFormat() : "Selecionar"
            lblISCMPAHoraInicio.text = hla.crossIscmpaHoraInicio ?? "Selecionar"
            lblISCMPAHoraFim.text = hla.crossIscmpaHoraFim ?? "Selecionar"
        } else {
            isNew = true
        }
    }
    
    func loadDataToModel() {
        if isNew {
            model.hla = HLA()
        }
        if let hla = model.hla {
            hla.dataInicio = lblDataInicio.text == "Selecionar" ? nil : lblDataInicio.text?.toDateBackEndFormat()
            hla.horaInicio = lblHoraInicio.text == "Selecionar" ? nil : lblHoraInicio.text
            hla.horaTermino = lblHoraTermino.text == "Selecionar" ? nil : lblHoraTermino.text
            hla.laboratorio = txtLaboratorio.text
            hla.crossHcpaDataInicio = lblHCPADataInicio.text == "Selecionar" ? nil : lblHCPADataInicio.text?.toDateBackEndFormat()
            hla.crossHcpaDataFim = lblHCPADataFim.text == "Selecionar" ? nil : lblHCPADataInicio.text?.toDateBackEndFormat()
            hla.crossHcpaHoraInicio = lblHCPAHoraInicio.text == "Selecionar" ? nil : lblHCPAHoraInicio.text
            hla.crossHcpaHoraFim = lblHCPAHoraFim.text == "Selecionar" ? nil : lblHCPAHoraFim.text
            hla.crossIscmpaDataInicio = lblISCMPADataInicio.text == "Selecionar" ? nil : lblISCMPADataInicio.text?.toDateBackEndFormat()
            hla.crossIscmpaDataFim = lblISCMPADataFim.text == "Selecionar" ? nil : lblISCMPADataFim.text?.toDateBackEndFormat()
            hla.crossIscmpaHoraInicio = lblISCMPAHoraInicio.text == "Selecionar" ? nil : lblISCMPAHoraInicio.text
            hla.crossIscmpaHoraFim = lblISCMPAHoraFim.text == "Selecionar" ? nil : lblISCMPAHoraFim.text

        }
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func backToMenu() {
        stopLoading()
        MessageHelper.showMessage(message: "Salvo com sucesso." ,backgroundColor: Colors.strongBlue)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSalvarTapped(_ sender : UIButton) {
        startLoading()
        loadDataToModel()
        model.updateHLA()
    }
    
    @IBAction func buttonDataInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblDataInicio.text == "Selecionar" ? Date() : lblDataInicio.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblDataInicio.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHCPADataInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblHCPADataInicio.text == "Selecionar" ? Date() : lblHCPADataInicio.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblHCPADataInicio.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHCPADataFimTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblHCPADataFim.text == "Selecionar" ? Date() : lblHCPADataFim.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblHCPADataFim.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonISCMPADataInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblISCMPADataInicio.text == "Selecionar" ? Date() : lblISCMPADataInicio.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblISCMPADataInicio.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonISCMPADataFimTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblISCMPADataFim.text == "Selecionar" ? Date() : lblISCMPADataFim.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date , didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblISCMPADataFim.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHoraInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora inicio" ,time: lblHoraInicio.text == "Selecionar" ? nil : lblHoraInicio.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHoraInicio.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHoraTerminoTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora termino" ,time: lblHoraTermino.text == "Selecionar" ? nil : lblHoraTermino.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHoraTermino.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHCPAHoraInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora HCPA inicio" ,time: lblHCPAHoraInicio.text == "Selecionar" ? nil : lblHCPAHoraInicio.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHCPAHoraInicio.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonHCPAHoraFimTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora HCPA fim" ,time: lblHCPAHoraFim.text == "Selecionar" ? nil : lblHCPAHoraFim.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHCPAHoraFim.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonISCMPAHoraInicioTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora ISCMPA inicio" ,time: lblISCMPAHoraInicio.text == "Selecionar" ? nil : lblISCMPAHoraInicio.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblISCMPAHoraInicio.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonISCMPAHoraFimTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora ISCMPA fim" ,time: lblISCMPAHoraFim.text == "Selecionar" ? nil : lblISCMPAHoraFim.text )
            super.popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblISCMPAHoraFim.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8
    }
}

extension HLATVC : HLATVMDelegate {
    
    func didFailUpdateHLA(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailFetchHLA(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didUpdateHLA() {
        backToMenu()
    }
    
    func didFetchHLA() {
        setStatusContentLoaded()
    }
}




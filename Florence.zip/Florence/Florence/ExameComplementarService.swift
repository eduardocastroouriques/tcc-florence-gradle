//
//  ExameComplementarService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 21/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
//
//  TesteClinicoService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper
import AlamofireObjectMapper

class ExameComplementarService {
    
    func fetchAllExames(idProcesso: Int, success: @escaping ([ExameComplementar]) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.exameComplementarAll + "/\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestArray(url: url, success: { (data) in
            guard let exames = data else { return }
            var examesList : [ExameComplementar] = []
            exames.forEach({
                let t = Mapper<ExameComplementar>().map(JSON: $0)
                if t != nil {
                    examesList.append(t!)
                }
            })
            success(examesList)
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateExame(idProcesso: Int , exame: ExameComplementar ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.exameComplementar
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: exame.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}

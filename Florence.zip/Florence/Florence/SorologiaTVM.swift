//
//  SorologiaTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 22/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol SorologiaTVMDelegate {
    func didUpdateSorologia()
    func didFetchSorologia()
    func didFailFetchSorologia(with error: String)
    func didFailUpdateSorologia(with error: String)
}

class SorologiaTVM {
    
    var sorologia : Sorologia?
    var processoID : Int?
    var delegate : SorologiaTVMDelegate!
    
    func fetchSorologia() {
        guard let idProcess = processoID else { return }
        SorologiaService().fetchSorologia(idProcesso: idProcess, success: {  [weak self] (sorologia) in
            guard let s = self else { return }
            s.sorologia = sorologia
            s.delegate.didFetchSorologia()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailFetchSorologia(with: error)
        }
    }
    
    func updateSorologia() {
        guard let sorologia = sorologia , let idProcess = processoID else { return }
        SorologiaService().updateSorologia(idProcesso: idProcess, sorologia: sorologia, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateSorologia()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailUpdateSorologia(with: error)
        }
    }
}

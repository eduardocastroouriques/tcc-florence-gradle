
import Foundation
import ObjectMapper


class ExameComplementar : NSObject, NSCoding, Mappable{
    
    var dataExame : String?
    var horaExame : String?
    var medico : String?
    var oid : Int?
    var resultado : String?
    var tipo : Int?
    var tipoOutro : String?
    
    
    class func newInstance(map: Map) -> Mappable?{
        return ExameComplementar()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        dataExame <- map["dataExame"]
        horaExame <- map["horaExame"]
        medico <- map["medico"]
        oid <- map["oid"]
        resultado <- map["resultado"]
        tipo <- map["tipo"]
        tipoOutro <- map["tipoOutro"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        dataExame = aDecoder.decodeObject(forKey: "dataExame") as? String
        horaExame = aDecoder.decodeObject(forKey: "horaExame") as? String
        medico = aDecoder.decodeObject(forKey: "medico") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        resultado = aDecoder.decodeObject(forKey: "resultado") as? String
        tipo = aDecoder.decodeObject(forKey: "tipo") as? Int
        tipoOutro = aDecoder.decodeObject(forKey: "tipoOutro") as? String
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if dataExame != nil{
            aCoder.encode(dataExame, forKey: "dataExame")
        }
        if horaExame != nil{
            aCoder.encode(horaExame, forKey: "horaExame")
        }
        if medico != nil{
            aCoder.encode(medico, forKey: "medico")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if resultado != nil{
            aCoder.encode(resultado, forKey: "resultado")
        }
        if tipo != nil{
            aCoder.encode(tipo, forKey: "tipo")
        }
        if tipoOutro != nil{
            aCoder.encode(tipoOutro, forKey: "tipoOutro")
        }
        
    }
    
}

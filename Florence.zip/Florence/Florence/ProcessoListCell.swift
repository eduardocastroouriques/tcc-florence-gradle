//
//  RecordListCell.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 03/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class ProcessoListCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblRG: UILabel!
    @IBOutlet weak var lblDataInternacao: UILabel!

    var content : ProcessoDoacao? {
        didSet {
            lblName.text = "Nome: \(content?.nome ?? "Não informado")"
            lblRG.text = "RG: \(content?.rg ?? "Não informado")"
            lblDataInternacao.text = "Data Internação: \(content?.dataInternacao.or("01-01-2017").toDateFrontEndFormat() ?? "Não informado")"
        }
    }
}

//
//  MenuProntuarioTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class MenuProntuarioTVC: BaseTableViewController {
    
    @IBOutlet weak var name : UILabel!
    
    var model = MenuProntuarioVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Prontuário"
        self.name.text = model.currentProntuario?.nome ?? "Não Informado"
        setBackButtonTextEmpty()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    // MARK: - Table view data source
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let id = segue.identifier else { return }
        switch id {
        case "goToDadosGerais":
            guard let vc = segue.destination as? DadosGeraisTVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToTestesClinicos":
            guard let vc = segue.destination as? TestesClinicosListVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToExamesComplementares":
            guard let vc = segue.destination as? ExameComplementarListVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToEntrevistaFamiliar":
            guard let vc = segue.destination as? EntrevistaFamiliarTVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToDVA":
            guard let vc = segue.destination as? DVAListVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToSorologia":
            guard let vc = segue.destination as? SorologiaTVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToExameDoacao":
            guard let vc = segue.destination as? ExameDoacaoTVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToSituacaoClinica":
            guard let vc = segue.destination as? SituacaoClinicaListVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToHLA":
            guard let vc = segue.destination as? HLATVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        case "goToObito":
            guard let vc = segue.destination as? ObitoTVC else { return }
            vc.model.processoID = model.currentProntuario?.oid
        default:
            break
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 11
    }
}

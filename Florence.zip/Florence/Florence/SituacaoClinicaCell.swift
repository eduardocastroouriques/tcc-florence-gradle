//
//  SituacaoClinicaCellTableViewCell.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class SituacaoClinicaCell: UITableViewCell {

    @IBOutlet weak var lblData: UILabel!
    @IBOutlet weak var lblHora: UILabel!
    @IBOutlet weak var lblTA: UILabel!
    @IBOutlet weak var lblDiurese: UILabel!
    @IBOutlet weak var lblSat: UILabel!
    @IBOutlet weak var lblPeep: UILabel!
    @IBOutlet weak var lblPins: UILabel!
    @IBOutlet weak var lblFr: UILabel!
    @IBOutlet weak var lblFio2: UILabel!
    
    var content : SituacaoClinica? {
        didSet {
            lblData.text = "Data: \(content?.dataSituacaoClinica.or("01-01-2017").toDateFrontEndFormat() ?? "Não informado")"
            lblHora.text = "Hora: \(content?.horaSituacaoClinica ?? "Não informado")"
            lblTA.text = "TA: \(content?.ta ?? "Não informado")"
            lblDiurese.text = "Diurese: \(content?.diurese ?? "Não informado")"
            lblSat.text = "Sat: \(content?.sat ?? "Não informado")"
            lblPeep.text = "Peep: \(content?.peep ?? "Não informado")"
            lblPins.text = "Pins: \(content?.pins ?? "Não informado")"
            lblFr.text = "Fr: \(content?.fr ?? "Não informado")"
            lblFio2.text = "Fio2: \(content?.fioDois ?? "Não informado")"
        }
    }
    
}

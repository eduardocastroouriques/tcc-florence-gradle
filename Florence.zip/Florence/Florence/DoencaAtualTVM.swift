//
//  DoencaAtualTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 29/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol DoencaAtualTVMDelegate {
    func didUpdateDoencaAtual()
    func didFetchDoencaAtual()
    func didFail(with error: String)
}

class DoencaAtualTVM {
    
    var doencaAtual : DoencaAtual?
    var processoID : Int?
    var delegate : DoencaAtualTVMDelegate!
    
    func fetchDoencaAtual() {
        guard let idProcess = processoID else { return }
        DoencaAtualService().fetchDoencaAtual(idProcesso: idProcess, success: {  [weak self] (doencaAtual) in
            guard let s = self else { return }
            s.doencaAtual = doencaAtual
            s.delegate.didFetchDoencaAtual()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
    
    func updateDoencaAtual() {
        guard let doencaAtual = doencaAtual , let idProcess = processoID else { return }
        DoencaAtualService().updateDoencaAtual(idProcesso: idProcess, doencaAtual: doencaAtual, success: {
            [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateDoencaAtual()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFail(with: error)
        }
    }
}


//
//  ObitoTVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 11/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol ObitoTVMDelegate {
    func didUpdateObito()
    func didFetchObito()
    func didFailUpdateObito(with error: String)
    func didFailFetchObito(with error: String)
}

class ObitoTVM {
    
    var obito : Obito?
    var processoID : Int?
    var delegate : ObitoTVMDelegate!
    
    func fetchObito() {
        guard let idProcess = processoID else { return }
        ObitoService().fetchObito(idProcesso: idProcess, success: { [weak self] (obito) in
            guard let s = self else { return }
            s.obito = obito
            s.delegate.didFetchObito()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailFetchObito(with: error)
        }
    }
    
    func updateObito() {
        guard let obito = obito , let idProcess = processoID else { return }
        ObitoService().updateObito(idProcesso: idProcess, obito: obito, success: { [weak self] in
                guard let s = self else { return }
                s.delegate.didUpdateObito()
            }) { [weak self] (error) in
                guard let s = self else { return }
                s.delegate.didFailUpdateObito(with: error)
            }
    }
}

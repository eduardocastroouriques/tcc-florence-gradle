//
//  Antecedentes.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class Antecedentes : NSObject, NSCoding, Mappable{
    
    var ap : String?
    var aptto : String?
    var asma : String?
    var cirurgiaPrevia : String?
    var dataCura : String?
    var dataDiagn : String?
    var dataTransfusao : String?
    var dm : String?
    var dmdesde : String?
    var doencaOcular : String?
    var doencaSnc : String?
    var dpoc : String?
    var dvp : String?
    var has : String?
    var hasDesde : String?
    var hepatite : String?
    var hiv : String?
    var homossexualismo : String?
    var iam : String?
    var informanteNome : String?
    var informanteParentesco : String?
    var irc : String?
    var maquiagemDefinitiva : String?
    var neoplasia : String?
    var oid : Int?
    var outrasDoencas : String?
    var piercing : String?
    var quimio : String?
    var radio : String?
    var sistemaPrisional : String?
    var sistemaPrisionalQDO : String?
    var tatuagem : String?
    var transfusao : String?
    var tuberculose : String?
    var tuberculoseTTO : String?
    var vacinasRecentes : String?
    
    
    class func newInstance(map: Map) -> Mappable?{
        return Antecedentes()
    }
    required init?(map: Map){}
    private override init(){}
    
    func mapping(map: Map)
    {
        ap <- map["ap"]
        aptto <- map["aptto"]
        asma <- map["asma"]
        cirurgiaPrevia <- map["cirurgiaPrevia"]
        dataCura <- map["dataCura"]
        dataDiagn <- map["dataDiagn"]
        dataTransfusao <- map["dataTransfusao"]
        dm <- map["dm"]
        dmdesde <- map["dmdesde"]
        doencaOcular <- map["doencaOcular"]
        doencaSnc <- map["doencaSnc"]
        dpoc <- map["dpoc"]
        dvp <- map["dvp"]
        has <- map["has"]
        hasDesde <- map["hasDesde"]
        hepatite <- map["hepatite"]
        hiv <- map["hiv"]
        homossexualismo <- map["homossexualismo"]
        iam <- map["iam"]
        informanteNome <- map["informanteNome"]
        informanteParentesco <- map["informanteParentesco"]
        irc <- map["irc"]
        maquiagemDefinitiva <- map["maquiagemDefinitiva"]
        neoplasia <- map["neoplasia"]
        oid <- map["oid"]
        outrasDoencas <- map["outrasDoencas"]
        piercing <- map["piercing"]
        quimio <- map["quimio"]
        radio <- map["radio"]
        sistemaPrisional <- map["sistemaPrisional"]
        sistemaPrisionalQDO <- map["sistemaPrisionalQDO"]
        tatuagem <- map["tatuagem"]
        transfusao <- map["transfusao"]
        tuberculose <- map["tuberculose"]
        tuberculoseTTO <- map["tuberculoseTTO"]
        vacinasRecentes <- map["vacinasRecentes"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        ap = aDecoder.decodeObject(forKey: "ap") as? String
        aptto = aDecoder.decodeObject(forKey: "aptto") as? String
        asma = aDecoder.decodeObject(forKey: "asma") as? String
        cirurgiaPrevia = aDecoder.decodeObject(forKey: "cirurgiaPrevia") as? String
        dataCura = aDecoder.decodeObject(forKey: "dataCura") as? String
        dataDiagn = aDecoder.decodeObject(forKey: "dataDiagn") as? String
        dataTransfusao = aDecoder.decodeObject(forKey: "dataTransfusao") as? String
        dm = aDecoder.decodeObject(forKey: "dm") as? String
        dmdesde = aDecoder.decodeObject(forKey: "dmdesde") as? String
        doencaOcular = aDecoder.decodeObject(forKey: "doencaOcular") as? String
        doencaSnc = aDecoder.decodeObject(forKey: "doencaSnc") as? String
        dpoc = aDecoder.decodeObject(forKey: "dpoc") as? String
        dvp = aDecoder.decodeObject(forKey: "dvp") as? String
        has = aDecoder.decodeObject(forKey: "has") as? String
        hasDesde = aDecoder.decodeObject(forKey: "hasDesde") as? String
        hepatite = aDecoder.decodeObject(forKey: "hepatite") as? String
        hiv = aDecoder.decodeObject(forKey: "hiv") as? String
        homossexualismo = aDecoder.decodeObject(forKey: "homossexualismo") as? String
        iam = aDecoder.decodeObject(forKey: "iam") as? String
        informanteNome = aDecoder.decodeObject(forKey: "informanteNome") as? String
        informanteParentesco = aDecoder.decodeObject(forKey: "informanteParentesco") as? String
        irc = aDecoder.decodeObject(forKey: "irc") as? String
        maquiagemDefinitiva = aDecoder.decodeObject(forKey: "maquiagemDefinitiva") as? String
        neoplasia = aDecoder.decodeObject(forKey: "neoplasia") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        outrasDoencas = aDecoder.decodeObject(forKey: "outrasDoencas") as? String
        piercing = aDecoder.decodeObject(forKey: "piercing") as? String
        quimio = aDecoder.decodeObject(forKey: "quimio") as? String
        radio = aDecoder.decodeObject(forKey: "radio") as? String
        sistemaPrisional = aDecoder.decodeObject(forKey: "sistemaPrisional") as? String
        sistemaPrisionalQDO = aDecoder.decodeObject(forKey: "sistemaPrisionalQDO") as? String
        tatuagem = aDecoder.decodeObject(forKey: "tatuagem") as? String
        transfusao = aDecoder.decodeObject(forKey: "transfusao") as? String
        tuberculose = aDecoder.decodeObject(forKey: "tuberculose") as? String
        tuberculoseTTO = aDecoder.decodeObject(forKey: "tuberculoseTTO") as? String
        vacinasRecentes = aDecoder.decodeObject(forKey: "vacinasRecentes") as? String
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if ap != nil{
            aCoder.encode(ap, forKey: "ap")
        }
        if aptto != nil{
            aCoder.encode(aptto, forKey: "aptto")
        }
        if asma != nil{
            aCoder.encode(asma, forKey: "asma")
        }
        if cirurgiaPrevia != nil{
            aCoder.encode(cirurgiaPrevia, forKey: "cirurgiaPrevia")
        }
        if dataCura != nil{
            aCoder.encode(dataCura, forKey: "dataCura")
        }
        if dataDiagn != nil{
            aCoder.encode(dataDiagn, forKey: "dataDiagn")
        }
        if dataTransfusao != nil{
            aCoder.encode(dataTransfusao, forKey: "dataTransfusao")
        }
        if dm != nil{
            aCoder.encode(dm, forKey: "dm")
        }
        if dmdesde != nil{
            aCoder.encode(dmdesde, forKey: "dmdesde")
        }
        if doencaOcular != nil{
            aCoder.encode(doencaOcular, forKey: "doencaOcular")
        }
        if doencaSnc != nil{
            aCoder.encode(doencaSnc, forKey: "doencaSnc")
        }
        if dpoc != nil{
            aCoder.encode(dpoc, forKey: "dpoc")
        }
        if dvp != nil{
            aCoder.encode(dvp, forKey: "dvp")
        }
        if has != nil{
            aCoder.encode(has, forKey: "has")
        }
        if hasDesde != nil{
            aCoder.encode(hasDesde, forKey: "hasDesde")
        }
        if hepatite != nil{
            aCoder.encode(hepatite, forKey: "hepatite")
        }
        if hiv != nil{
            aCoder.encode(hiv, forKey: "hiv")
        }
        if homossexualismo != nil{
            aCoder.encode(homossexualismo, forKey: "homossexualismo")
        }
        if iam != nil{
            aCoder.encode(iam, forKey: "iam")
        }
        if informanteNome != nil{
            aCoder.encode(informanteNome, forKey: "informanteNome")
        }
        if informanteParentesco != nil{
            aCoder.encode(informanteParentesco, forKey: "informanteParentesco")
        }
        if irc != nil{
            aCoder.encode(irc, forKey: "irc")
        }
        if maquiagemDefinitiva != nil{
            aCoder.encode(maquiagemDefinitiva, forKey: "maquiagemDefinitiva")
        }
        if neoplasia != nil{
            aCoder.encode(neoplasia, forKey: "neoplasia")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        if outrasDoencas != nil{
            aCoder.encode(outrasDoencas, forKey: "outrasDoencas")
        }
        if piercing != nil{
            aCoder.encode(piercing, forKey: "piercing")
        }
        if quimio != nil{
            aCoder.encode(quimio, forKey: "quimio")
        }
        if radio != nil{
            aCoder.encode(radio, forKey: "radio")
        }
        if sistemaPrisional != nil{
            aCoder.encode(sistemaPrisional, forKey: "sistemaPrisional")
        }
        if sistemaPrisionalQDO != nil{
            aCoder.encode(sistemaPrisionalQDO, forKey: "sistemaPrisionalQDO")
        }
        if tatuagem != nil{
            aCoder.encode(tatuagem, forKey: "tatuagem")
        }
        if transfusao != nil{
            aCoder.encode(transfusao, forKey: "transfusao")
        }
        if tuberculose != nil{
            aCoder.encode(tuberculose, forKey: "tuberculose")
        }
        if tuberculoseTTO != nil{
            aCoder.encode(tuberculoseTTO, forKey: "tuberculoseTTO")
        }
        if vacinasRecentes != nil{
            aCoder.encode(vacinasRecentes, forKey: "vacinasRecentes")
        }
        
    }
    
}

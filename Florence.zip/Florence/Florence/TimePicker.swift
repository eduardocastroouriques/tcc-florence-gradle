//
//  TimePicker.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class TimePicker: IBD_View {

    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var lblTitle: UILabel!
    
    var didConfirm: ((String) -> Void)?
    var didCancel: (() -> Void)?
    
    var hours : [String] {
        var h : [String] = []
        for i in 0...23 {
            if i < 10 {
                h.append("0\(i)")
            } else {
                h.append(String(i))
            }
        }
        return h
    }
    var minutes : [String] {
            var minuts : [String] = []
            for i in 0...59 {
                if i < 10 {
                    minuts.append("0\(i)")
                } else {
                    minuts.append(String(i))
                }
            }
            return minuts
    }
    var seconds : [String] {
        var seconds : [String] = []
        for i in 0...59 {
            if i < 10 {
                seconds.append("0\(i)")
            } else {
                seconds.append(String(i))
            }
        }
        return seconds
    }
    
    static func show(title: String, time: String? = "00:00:00") -> TimePicker {
        let timePicker = TimePicker.loadFromNib(name: "TimePicker") as! TimePicker
        timePicker.lblTitle.text = title
        let timeArray = time != nil ? Array(time!) : Array("00:00:00")
        guard let hourIndex = timePicker.hours.index(of: "\(timeArray[0])\(timeArray[1])"),
        let minIndex = timePicker.minutes.index(of: "\(timeArray[3])\(timeArray[4])"),
            let secIndex = timePicker.seconds.index(of: "\(timeArray[6])\(timeArray[7])") else { return timePicker }
        timePicker.picker.selectRow(hourIndex, inComponent: 0, animated: true)
        timePicker.picker.selectRow(minIndex, inComponent: 1, animated: true)
        timePicker.picker.selectRow(secIndex, inComponent: 2, animated: true)
        return timePicker
    }
    
    @IBAction func buttonConfirmarTapped(_ sender : UIButton) {
        let hour = hours[picker.selectedRow(inComponent: 0)]
        let min = minutes[picker.selectedRow(inComponent: 1)]
        let second = seconds[picker.selectedRow(inComponent: 2)]
        didConfirm?("\(hour):\(min):\(second)")
    }
    
    @IBAction func buttonCancelarTapped(_ sender : UIButton) {
        didCancel?()
    }
}

extension TimePicker : UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch component {
        case 0:
            return 24
        case 1:
            return 60
        case 2:
            return 60
        default:
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var label = view as? UILabel
        if label == nil {
            label = UILabel(frame: CGRect(x: 0, y: 0, width: 100 , height: 20))
            label?.textColor = Colors.strongBlue
            label?.textAlignment = .center
        }
        switch component {
        case 0:
            label?.text = hours[row]
        case 1:
            label?.text = minutes[row]
        case 2:
            label?.text = minutes[row]
        default:
            return label!
        }
        return label!
    }
    
}

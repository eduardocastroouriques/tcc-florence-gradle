//
//  DVACell.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 08/10/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class DVACell: UITableViewCell {

    @IBOutlet weak var lblTipo: UILabel!
    @IBOutlet weak var lblAmp: UILabel!
    @IBOutlet weak var lblMl: UILabel!
    @IBOutlet weak var lblKgMinMAut: UILabel!
    @IBOutlet weak var lblInicioMAut: UILabel!
    @IBOutlet weak var lblKgMinMax: UILabel!
    @IBOutlet weak var lblMLHMax: UILabel!
    
    var content : DVA? {
        didSet {
            lblTipo.text = "Tipo: \(content?.nome ?? "Não informado")"
            lblAmp.text = "Amp: \(content?.amp ?? "Não informado")"
            if let ml = content?.mlPorHora {
                lblMl.text = "Ml/h: \(ml)"
            } else { lblMl.text = "Ml/h: Não Informado" }
            if let kg = content?.kg {
                lblKgMinMAut.text = "μ/Kg/min: \(kg)"
            } else { lblKgMinMAut.text = "μ/Kg/min Máximo: Não informado " }
            lblInicioMAut.text = "Hora inicio: \(content?.inicio ?? "Não informado" )"
            lblKgMinMax.text = "μ/Kg/min Máximo: \(content?.doseMaximaKg ?? "Não informado")"
            lblMLHMax.text =  "Ml/H Máximo: \(content?.doseMaximaMlPorHora ?? "Não informado")"
        }
    }
    
}

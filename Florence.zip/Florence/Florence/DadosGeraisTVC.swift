//
//  DadosGeraisTVC.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 24/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import UIKit

class DadosGeraisTVC: BaseTableViewController {
    
    @IBOutlet weak var txtHospital : UITextField!
    @IBOutlet weak var lblDataInternacao : UILabel!
    @IBOutlet weak var txtSetor : UITextField!
    @IBOutlet weak var txtLeito : UITextField!
    @IBOutlet weak var txtTelefone : UITextField!
    @IBOutlet weak var txtInformante : UITextField!
    @IBOutlet weak var txtNome : UITextField!
    @IBOutlet weak var txtRG : UITextField!
    @IBOutlet weak var txtCPF : UITextField!
    @IBOutlet weak var txtEndereco : UITextField!
    @IBOutlet weak var txtFiliacao : UITextField!
    @IBOutlet weak var txtTelefoneContato : UITextField!
    @IBOutlet weak var txtCNS : UITextField!
    @IBOutlet weak var lblDataNasc : UILabel!
    @IBOutlet weak var txtNumProntuario : UITextField!
    @IBOutlet weak var txtIdade : UITextField!
    @IBOutlet weak var txtPeso : UITextField!
    @IBOutlet weak var txtAltura : UITextField!
    @IBOutlet weak var segmentedSexo : UISegmentedControl!
    @IBOutlet weak var segmentedEstadoCivil : UISegmentedControl!
    @IBOutlet weak var segmentedTipoSang : UISegmentedControl!
    @IBOutlet weak var segmentedTipoSangAux : UISegmentedControl!
    @IBOutlet weak var segmentedCausaMorte : UISegmentedControl!
    @IBOutlet weak var txtCausaMorteOutra : UITextField!
    @IBOutlet weak var txtCausaMorteDecorrente : UITextField!
    @IBOutlet weak var segmentedCircunstancia : UISegmentedControl!
    @IBOutlet weak var txtCircunstancia : UITextField!
    @IBOutlet weak var txtSedacao : UITextField!
    @IBOutlet weak var lblDataSusp : UILabel!
    @IBOutlet weak var lblHoraSusp : UILabel!
    @IBOutlet weak var txtTemperatura : UITextField!
    @IBOutlet weak var txtTA : UITextField!
    
    var isNewProcess : Bool = false
    var model = DadosGeraisTVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Dados Gerais"
        model.delegate = self 
        if isNewProcess == false {
            guard let id = model.processoID else { return }
            model.fetchProcesso(id: id)
            setStatusContentLoading()
        } else {
            setupContent()
        }
        
        setBackButtonTextEmpty()
    }
    
    func setStatusContentLoading() {
        startLoading()
    }
    
    func setStatusContentLoaded(){
        setupContent()
        stopLoading()
    }
    
    func setupContent() {
        guard let p = model.processo else { return }
        txtHospital.text = p.hospital
        lblDataInternacao.text = p.dataInternacao != nil ? p.dataInternacao!.toDateFrontEndFormat() : "Selecionar"
        txtSetor.text = p.setor
        txtLeito.text = p.leito
        txtTelefone.text = p.telefone
        txtInformante.text = p.informante
        txtNome.text = p.nome
        txtRG.text = p.rg
        txtCPF.text = p.cpf
        txtEndereco.text = p.endereco
        txtFiliacao.text = p.filiacao
        txtTelefoneContato.text = p.telefoneFamiliar
        txtCNS.text = p.cns
        lblDataNasc.text = p.dataNascimento != nil ? p.dataNascimento!.toDateFrontEndFormat() : "Selecionar"
        txtNumProntuario.text = p.prontuarioHospital
        txtIdade.text = String(p.idade ?? 0)
        txtPeso.text = String(p.peso ?? 0)
        txtAltura.text = String(p.altura ?? 0)
        if let sexo = p.sexo {
            segmentedSexo.selectedSegmentIndex = sexo == "Masculino" ? 0 : 1
        } else { segmentedSexo.selectedSegmentIndex = 0 }
        segmentedEstadoCivil.selectedSegmentIndex = getSegmentedIndexForEstadoCivil(estado: p.estadoCivil)
        let tpValues = getSegmentedIndexForTS(tp: p.tipagem)
        segmentedTipoSang.selectedSegmentIndex = tpValues.0
        segmentedTipoSangAux.selectedSegmentIndex = tpValues.1
        txtCausaMorteOutra.text = p.causaDaMorte
        segmentedCausaMorte.selectedSegmentIndex = getSegmentedIndexForCausaMorte(causaMorte: p.causaDaMorte)
        txtCausaMorteDecorrente.text = p.causaDaMorteDecorrenteDe
        txtCircunstancia.text = p.causaDaMorteCircunstancia
        segmentedCircunstancia.selectedSegmentIndex = getSegmentedIndexForCircunstancia(circunstantia: p.causaDaMorteCircunstancia)
        txtSedacao.text = p.protocoloSedacao
        lblDataSusp.text = p.protocoloDataSuspensao != nil ? p.protocoloDataSuspensao!.toDateFrontEndFormat() : "Selecionar"
        lblHoraSusp.text = p.protocoloHoraSuspensao ?? "Selecionar"
        txtTemperatura.text = String(p.protocoloTemperatura ?? 0)
        txtTA.text = p.protocoloTa
    }
    
    @IBAction func buttonHoraSuspensaoTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let picker = TimePicker.show(title: "Hora Suspensão",time: lblHoraSusp.text == "Selecionar" ? nil : lblHoraSusp.text)
            popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            picker.didCancel = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            picker.didConfirm = { [weak self] b in
                guard let s = self else { return }
                s.lblHoraSusp.text = b
                s.popUpContent?.removeFromSuperview()
            }
            picker.center = popUpContent!.center
            popUpContent!.addSubview(picker)
            window.addSubview(popUpContent!)
        }
    }
    @IBAction func buttonDataSuspTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblDataSusp.text == "Selecionar" ? Date() : lblDataSusp.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date, didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblDataSusp.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonDataInternacaoTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblDataInternacao.text == "Selecionar" ? Date() : lblDataInternacao.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date, didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblDataInternacao.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    @IBAction func buttonDataNascTapped(_ sender: UIButton) {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window, let barHeight = navigationController?.navigationBar.frame.height {
            let date = lblDataNasc.text == "Selecionar" ? Date() : lblDataNasc.text?.toDate()
            let datePicker = CalendarPicker.show(selectedDate: date, didSelect: { [weak self] (date) in
                guard let s = self else { return }
                s.lblDataNasc.text = date.toStringFrontEnd()
                s.popUpContent?.removeFromSuperview()
            })
            datePicker.didDismiss = { [weak self] in
                guard let s = self else { return }
                s.popUpContent?.removeFromSuperview()
            }
            popUpContent = UIView(frame: CGRect(x: 0, y: 0, width: window.frame.width, height: window.frame.height + barHeight))
            popUpContent!.backgroundColor = UIColor.clear.withAlphaComponent(0.4)
            popUpContent!.center = window.center
            datePicker.center = popUpContent!.center
            popUpContent!.addSubview(datePicker)
            window.addSubview(popUpContent!)
        }
    }
    
    
    func getSegmentedIndexForEstadoCivil(estado: String?) -> Int {
        guard let estado = estado else { return 0 }
        return model.kvEstadoCivil.filter({$0.0 == estado}).first?.1 ?? 0
    }
    
    func getStringForEstadoCivil(index: Int) -> String {
        return model.kvEstadoCivil.filter({$0.1 == index}).first?.0 ?? ""
    }
    
    func getSegmentedIndexForTS(tp: String?) -> (Int,Int) {
        guard let tp = tp else { return (0,0) }
        return model.kvTipoSang.filter({$0.0 == tp}).first?.1 ?? (0,0)
    }
    
    func getStringForTS(index: (Int,Int)) -> String {
        return model.kvTipoSang.filter({ $0.1.0 == index.0 &&  $0.1.1 == index.1 }).first?.0 ?? ""
    }
    
    func getSegmentedIndexForCausaMorte(causaMorte: String?) -> Int {
        guard let causaMorte = causaMorte else { return 0 }
        return model.kvCausaMorte.filter({$0.0 == causaMorte}).first?.1 ?? 0
    }
    
    func getStringForCausaMorte(index: Int) -> String {
        return model.kvCausaMorte.filter({$0.1 == index}).first?.0 ?? ""
    }
    
    func getSegmentedIndexForCircunstancia(circunstantia: String?) -> Int {
        guard let circunstantia = circunstantia else { return 0 }
        return model.kvCircunstancia.filter({$0.0 == circunstantia}).first?.1 ?? 0
    }
    
    func getStringForCircunstancia(index: Int) -> String {
        return model.kvCircunstancia.filter({$0.1 == index}).first?.0 ?? ""
    }
    
    @IBAction func btnSaveTapped(_ sender : UIButton) {
        setStatusContentLoading()
        loadDataToModel()
        model.updateProcesso()
    }
    
    func loadDataToModel() {
        if isNewProcess {
            model.processo = ProcessoDoacao()
        }

        if let process = model.processo {
            process.hospital = txtHospital.text
            process.dataInternacao = lblDataInternacao.text == "Selecionar" ? nil : lblDataInternacao.text?.toDateBackEndFormat()
            process.setor = txtSetor.text
            process.leito = txtLeito.text
            process.telefone = txtTelefone.text
            process.informante = txtInformante.text
            process.nome = txtNome.text
            process.rg = txtRG.text
            process.cpf = txtCPF.text
            process.endereco = txtEndereco.text
            process.filiacao = txtFiliacao.text
            process.telefoneFamiliar = txtTelefoneContato.text
            process.cns = txtCNS.text
            process.dataNascimento = lblDataNasc.text == "Selecionar" ? nil : lblDataNasc.text?.toDateBackEndFormat()
            process.prontuarioHospital = txtNumProntuario.text
            if let idade = txtIdade.text {
                process.idade = Int(idade)
            }
            if let peso = txtPeso.text {
                process.peso = Float(peso)
            }
            if let altura = txtAltura.text {
                process.altura = Float(altura)
            }
            process.sexo = segmentedSexo.selectedSegmentIndex == 0 ? "Masculino" : "Feminino"
            process.estadoCivil = getStringForEstadoCivil(index: segmentedEstadoCivil.selectedSegmentIndex)
            process.tipagem = getStringForTS(index: (segmentedTipoSang.selectedSegmentIndex, segmentedTipoSangAux.selectedSegmentIndex))
            process.causaDaMorte = getStringForCausaMorte(index: segmentedCausaMorte.selectedSegmentIndex)
            process.causaDaMorteOutra = txtCausaMorteOutra.text
            process.causaDaMorteDecorrenteDe = txtCausaMorteDecorrente.text
            process.causaDaMorteCircunstancia = getStringForCircunstancia(index: segmentedCircunstancia.selectedSegmentIndex)
            process.causaDaMorteCircunstanciaAcidente = txtCircunstancia.text
            process.protocoloSedacao = txtSedacao.text
            process.protocoloDataSuspensao = lblDataSusp.text == "Selecionar" ? nil : lblDataSusp.text?.toDateBackEndFormat()
            process.protocoloHoraSuspensao = lblHoraSusp.text == "Selecionar" ? nil : lblHoraSusp.text
            if let temp = txtTemperatura.text {
                process.protocoloTemperatura = Float(temp)
            }
            process.protocoloTa = txtTA.text
        }
    }
    
    func backToMenu() {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: "Salvo com sucesso.",backgroundColor: Colors.strongBlue)
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 21
    }
}

extension DadosGeraisTVC : DadosGeraisTVMDelegate {
    
    func didUpdateProcesso() {
        backToMenu()
    }
    
    func didFailToFetch(with error: String) {
        stopLoading()
        navigationController?.popViewController(animated: true)
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFailToUpdate(with error: String) {
        stopLoading()
        MessageHelper.showMessage(message: error ,backgroundColor: Colors.strongPink)
    }
    
    func didFetchProcesso() {
        setStatusContentLoaded()
    }
}


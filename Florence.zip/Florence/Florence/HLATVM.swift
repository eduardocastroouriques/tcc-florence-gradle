//
//  HLATVM.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation

protocol HLATVMDelegate {
    func didUpdateHLA()
    func didFetchHLA()
    func didFailUpdateHLA(with error: String)
    func didFailFetchHLA(with error: String)
}

class HLATVM {
    
    var hla : HLA?
    var processoID : Int?
    var delegate : HLATVMDelegate!
    
    func fetchHLA() {
        guard let idProcess = processoID else { return }
        HLAService().fetchHLA(idProcesso: idProcess, success: {  [weak self] (hla) in
            guard let s = self else { return }
            s.hla = hla
            s.delegate.didFetchHLA()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailFetchHLA(with: error)        }
    }
    
    func updateHLA() {
        guard let hla = hla , let idProcess = processoID else { return }
        HLAService().updateHLA(idProcesso: idProcess, hla: hla, success: { [weak self] in
            guard let s = self else { return }
            s.delegate.didUpdateHLA()
        }) { [weak self] (error) in
            guard let s = self else { return }
            s.delegate.didFailUpdateHLA(with: error)
        }
    }
}

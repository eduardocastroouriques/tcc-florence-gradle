//
//  EntrevistaFamiliarService.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 22/09/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper

class EntrevistaFamiliarService {
    
    func fetchEntrevista(idProcesso: Int ,success: @escaping (EntrevistaFamilar) -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.entrevistaFamiliarFetch + "\(idProcesso)"
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestGetOne(url: url, success: { (data) in
            guard let entrevista = data else {
                success(EntrevistaFamilar())
                return
            }
            let ent = Mapper<EntrevistaFamilar>().map(JSON: entrevista)
            if ent != nil {
                success(ent!)
            }
        }, failure: { (error) in
            failure(error)
        })
    }
    
    func updateEntrevista(idProcesso: Int , entrevista: EntrevistaFamilar ,success: @escaping () -> (), failure: @escaping (String) -> ()) {
        let urlStr = API.entrevistaFamiliarUpdate
        guard let url = URL(string: urlStr) else { return }
        Service.sharedInstance.requestPostOneNested(url: url, parameters: entrevista.toJSON(), processId: idProcesso, success: {
            success()
        }) { (error) in
            failure(error)
        }
    }
}


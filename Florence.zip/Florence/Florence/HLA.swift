//
//  HLA.swift
//  Florence
//
//  Created by vicente de paula miraber filho on 05/11/17.
//  Copyright © 2017 Vicente de Paula Miraber Filho. All rights reserved.
//

import Foundation
import ObjectMapper


class HLA : NSObject, NSCoding, Mappable{
    
    var crossHcpaDataFim : String?
    var crossHcpaDataInicio : String?
    var crossHcpaHoraFim : String?
    var crossHcpaHoraInicio : String?
    var crossIscmpaDataFim : String?
    var crossIscmpaDataInicio : String?
    var crossIscmpaHoraFim : String?
    var crossIscmpaHoraInicio : String?
    var dataInicio : String?
    var horaInicio : String?
    var horaTermino : String?
    var laboratorio : String?
    var oid : Int?
    var processoDoacao : ProcessoDoacao?
    
    
    class func newInstance(map: Map) -> Mappable?{
        return HLA()
    }
    required init?(map: Map){}
    override init(){}
    
    func mapping(map: Map)
    {
        crossHcpaDataFim <- map["crossHcpaDataFim"]
        crossHcpaDataInicio <- map["crossHcpaDataInicio"]
        crossHcpaHoraFim <- map["crossHcpaHoraFim"]
        crossHcpaHoraInicio <- map["crossHcpaHoraInicio"]
        crossIscmpaDataFim <- map["crossIscmpaDataFim"]
        crossIscmpaDataInicio <- map["crossIscmpaDataInicio"]
        crossIscmpaHoraFim <- map["crossIscmpaHoraFim"]
        crossIscmpaHoraInicio <- map["crossIscmpaHoraInicio"]
        dataInicio <- map["dataInicio"]
        horaInicio <- map["horaInicio"]
        horaTermino <- map["horaTermino"]
        laboratorio <- map["laboratorio"]
        oid <- map["oid"]
        
    }
    
    @objc required init(coder aDecoder: NSCoder)
    {
        crossHcpaDataFim = aDecoder.decodeObject(forKey: "crossHcpaDataFim") as? String
        crossHcpaDataInicio = aDecoder.decodeObject(forKey: "crossHcpaDataInicio") as? String
        crossHcpaHoraFim = aDecoder.decodeObject(forKey: "crossHcpaHoraFim") as? String
        crossHcpaHoraInicio = aDecoder.decodeObject(forKey: "crossHcpaHoraInicio") as? String
        crossIscmpaDataFim = aDecoder.decodeObject(forKey: "crossIscmpaDataFim") as? String
        crossIscmpaDataInicio = aDecoder.decodeObject(forKey: "crossIscmpaDataInicio") as? String
        crossIscmpaHoraFim = aDecoder.decodeObject(forKey: "crossIscmpaHoraFim") as? String
        crossIscmpaHoraInicio = aDecoder.decodeObject(forKey: "crossIscmpaHoraInicio") as? String
        dataInicio = aDecoder.decodeObject(forKey: "dataInicio") as? String
        horaInicio = aDecoder.decodeObject(forKey: "horaInicio") as? String
        horaTermino = aDecoder.decodeObject(forKey: "horaTermino") as? String
        laboratorio = aDecoder.decodeObject(forKey: "laboratorio") as? String
        oid = aDecoder.decodeObject(forKey: "oid") as? Int
        
    }
    
    @objc func encode(with aCoder: NSCoder)
    {
        if crossHcpaDataFim != nil{
            aCoder.encode(crossHcpaDataFim, forKey: "crossHcpaDataFim")
        }
        if crossHcpaDataInicio != nil{
            aCoder.encode(crossHcpaDataInicio, forKey: "crossHcpaDataInicio")
        }
        if crossHcpaHoraFim != nil{
            aCoder.encode(crossHcpaHoraFim, forKey: "crossHcpaHoraFim")
        }
        if crossHcpaHoraInicio != nil{
            aCoder.encode(crossHcpaHoraInicio, forKey: "crossHcpaHoraInicio")
        }
        if crossIscmpaDataFim != nil{
            aCoder.encode(crossIscmpaDataFim, forKey: "crossIscmpaDataFim")
        }
        if crossIscmpaDataInicio != nil{
            aCoder.encode(crossIscmpaDataInicio, forKey: "crossIscmpaDataInicio")
        }
        if crossIscmpaHoraFim != nil{
            aCoder.encode(crossIscmpaHoraFim, forKey: "crossIscmpaHoraFim")
        }
        if crossIscmpaHoraInicio != nil{
            aCoder.encode(crossIscmpaHoraInicio, forKey: "crossIscmpaHoraInicio")
        }
        if dataInicio != nil{
            aCoder.encode(dataInicio, forKey: "dataInicio")
        }
        if horaInicio != nil{
            aCoder.encode(horaInicio, forKey: "horaInicio")
        }
        if horaTermino != nil{
            aCoder.encode(horaTermino, forKey: "horaTermino")
        }
        if laboratorio != nil{
            aCoder.encode(laboratorio, forKey: "laboratorio")
        }
        if oid != nil{
            aCoder.encode(oid, forKey: "oid")
        }
        
    }
    
}

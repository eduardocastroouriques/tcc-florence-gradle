//
//  CalendarPicker.swift
//  Unicred
//
//  Created by Vicente de paula miraber filho on 03/05/17.
//  Copyright © 2017 VPMF. All rights reserved.
//
import FSCalendar

class CalendarPicker: UIView {
    
    // MARK: - Private
    
    fileprivate lazy var gmtDate: Date = {
        return FSCalendar().today ?? Date()
    }()
    
    fileprivate lazy var shadowView: UIView = {
        let shadowView = UIView(frame: self.bounds)
        shadowView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        let shadowViewTap = UITapGestureRecognizer(target: self, action: #selector(CalendarPicker.dismiss))
        shadowView.addGestureRecognizer(shadowViewTap)
        return shadowView
    }()
    
    // MARK: - Public
    
    lazy var calendar: FSCalendar = {
        let width = min(self.bounds.size.width-40, 500)
        let cal = FSCalendar(frame: CGRect(x: 0, y: 0, width: width, height: 300))
        cal.locale = Locale(identifier: "pt_BR")
        cal.backgroundColor = Colors.backgroundBlue
        cal.appearance.todayColor = Colors.lightBlue
        cal.appearance.headerTitleColor = Colors.strongBlue
        cal.appearance.weekdayTextColor = Colors.strongBlue
        cal.appearance.selectionColor = Colors.strongBlue
        cal.delegate = self
        return cal
    }()
    
    @discardableResult static func show(selectedDate: Date?, didSelect: @escaping ((Date) -> Void)) -> CalendarPicker {
        
        let picker = CalendarPicker()
        
        // convert from gmt 0
        let timeInterval = TimeInterval(TimeZone.current.secondsFromGMT(for: picker.gmtDate)) * -1
        let selectedDate = selectedDate?.addingTimeInterval(timeInterval)
        
        picker.configureView()
        picker.didSelect = didSelect

        
        if selectedDate != nil {
            picker.calendar.select(selectedDate, scrollToDate: true)
        }
        return picker
    }
    
    var didSelect: ((Date) -> Void)?
    
    var didDismiss: ((Void) -> Void)?
}

// MARK: - Private
fileprivate extension CalendarPicker {
    
    func configureView() {
        if let window = (UIApplication.shared.delegate as? AppDelegate)?.window {
            frame = UIScreen.main.bounds
            addSubview(shadowView)
            addSubview(calendar)
            calendar.centerIn(self)
            calendar.clipsToBounds = true
            IBD_View.applyCornerRadius(calendar)
            window.addSubview(self)
        }
    }
    
    @objc func dismiss() {
        didDismiss?()
        removeFromSuperview()
    }
}

// MARK: - FSCalendarDelegate
extension CalendarPicker: FSCalendarDelegate {
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        let date = date.addingTimeInterval((TimeInterval(TimeZone.current.secondsFromGMT(for: gmtDate))))
        didSelect?(date)
        didSelect = nil
        DispatchQueue.main.async { [weak self] in
            self?.removeFromSuperview()
        }
    }
}
